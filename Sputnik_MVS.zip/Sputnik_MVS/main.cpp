﻿#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <map>
#include <unordered_map>
#include <filesystem>
#include <cmath>
#include <set>
#include <chrono>
#include <assert.h>
#include <sstream>
#include <tuple>
#include <algorithm>



#define SEED 987654321

static uint32_t z1 = SEED, z2 = SEED, z3 = SEED, z4 = SEED;

unsigned int lfsr113_Bits(void)
{
    //https://stackoverflow.com/questions/1167253/implementation-of-rand
    //static unsigned int z1 = 12345, z2 = 12345, z3 = 12345, z4 = 12345;
    unsigned int b;
    b = ((z1 << 6) ^ z1) >> 13;
    z1 = ((z1 & 4294967294U) << 18) ^ b;
    b = ((z2 << 2) ^ z2) >> 27;
    z2 = ((z2 & 4294967288U) << 2) ^ b;
    b = ((z3 << 13) ^ z3) >> 21;
    z3 = ((z3 & 4294967280U) << 7) ^ b;
    b = ((z4 << 3) ^ z4) >> 12;
    z4 = ((z4 & 4294967168U) << 13) ^ b;
    return (z1 ^ z2 ^ z3 ^ z4);
}


enum sputnik_status { SputnikIdle, Monitoring, SputnikDumping, Overflow };



enum session_break { Start_monitoring, Start_dumping, Out_of_range, Dumped_all_data, Delay_in_shadow, Switched_to_other, OOM };
enum station_status { StationIdle, StationDumping };

enum modeler_event_name {
    Empty_event,
    Sputnik_Earth_in,
    Sputnik_Earth_out,
    Sputnik_Start_monitoring,
    Sputnik_End_monitoring,
    Station_Sputnik_in_range,
    Station_Sputnik_out_of_range,
    Data_transfer_start,
    Data_transfer_end
};

std::vector<std::string> split(std::string s, std::string delimiter) {
    size_t pos_start = 0, pos_end, delim_len = delimiter.length();
    std::string token;
    std::vector<std::string> res;

    while ((pos_end = s.find(delimiter, pos_start)) != std::string::npos) {
        token = s.substr(pos_start, pos_end - pos_start);
        pos_start = pos_end + delim_len;
        res.push_back(token);
    }

    res.push_back(s.substr(pos_start));
    return res;
}


struct sputnik {
    std::string id = "";
    std::string type = "";
    double transfer_speed = 0;
    double initial_storage = 0;
    double storage_size = 0;
    double capture_speed = 0;
    std::vector<std::vector<double> > AreaAccess;
    void from_file(std::string filename) {
        std::ifstream file(filename);
        std::vector<std::string> s_tmp = split(filename, "\\");

        id = s_tmp[s_tmp.size() - 1];
        id = id.substr(0, id.size() - 3);
        std::string kino = "Kinosputnik";
        std::string zorky = "Zorky";

        if (id.substr(0, kino.size()) == kino) {
            type = "Kinosputnik";
            id = id.substr(kino.size() + 1, id.size() - kino.size() - 2);

            storage_size = 1024*1024;
            transfer_speed = 128;
            capture_speed = 512;

            //storage_size = 1000;
            //transfer_speed = 0.125;
            //capture_speed = 0.5;
        }
        else {
            //Zorky
            type = "Zorky";
            id = id.substr(zorky.size() + 1, id.size() - zorky.size() - 2);
            //storage_size = 500;
            //transfer_speed = 0.03125;
            //capture_speed = 0.5;
            storage_size = 512*1024;
            transfer_speed = 32;
            capture_speed = 512;
        }

        if (file.is_open()) {
            std::string line;
            while (std::getline(file, line)) {

                std::vector<std::string> tmp = split(line, ",");
                std::vector<double> tmp_int;
                for (unsigned int j = 0; j < tmp.size(); j++) {
                    tmp_int.push_back(std::stod(tmp[j]));
                }
                AreaAccess.push_back(tmp_int);

            }
        }
    }


};

struct station {
    std::string id = "";
    std::map < std::string, std::vector<std::vector<double> > > SatelliteAccess;
    void from_file(std::string filename) {
        std::ifstream file(filename);
        std::vector<std::string> s_tmp = split(filename, "\\");

        id = s_tmp[s_tmp.size() - 1];
        id = id.substr(0, id.size() - 4);

        //a.id = ?
        std::vector<std::vector<double> > intervals;
        unsigned int counter = 0;
        if (file.is_open()) {

            std::string line;
            std::string current_sputnik = "";

            while (std::getline(file, line)) {
                if (line[0] == '*') {
                    if (intervals.size() != 0) {
                        SatelliteAccess[current_sputnik] = intervals;
                        intervals.clear();
                    }
                    current_sputnik = line.substr(1, line.size() - 1);
                    counter++;
                }
                else {
                    std::vector<std::string> tmp = split(line, ",");
                    std::vector<double> tmp_int;
                    for (unsigned int j = 0; j < tmp.size(); j++) {
                        tmp_int.push_back(std::stod(tmp[j]));
                    }
                    intervals.push_back(tmp_int);
                }
            }
            SatelliteAccess[current_sputnik] = intervals;
        }
    }
};


struct modeler_event {
    double time_point = 0;

    uint32_t sputnik_id = 0;
    uint32_t station_id = 0;
    double time_end = 0;
    double data_sent = 0;
    modeler_event_name me_name = modeler_event_name::Empty_event;

    std::string to_string(std::vector<std::string>& sputnik_id_map, std::vector<std::string>& station_id_map) {
        std::string res;
        res += std::to_string(time_point) + " " + sputnik_id_map[sputnik_id] + " " + station_id_map[station_id] + " ";
        res += std::to_string(time_end) + " " + std::to_string(data_sent);
        switch (me_name) {
        case modeler_event_name::Empty_event:
            res += " Empty_event";
            break;
        case modeler_event_name::Sputnik_Earth_in:
            res += " Sputnik_Earth_in";
            break;
        case modeler_event_name::Sputnik_Earth_out:
            res += " Sputnik_Earth_out";
            break;
        case modeler_event_name::Sputnik_Start_monitoring:
            res += " Sputnik_Start_monitoring";
            break;
        case modeler_event_name::Sputnik_End_monitoring:
            res += " Sputnik_End_monitoring";
            break;
        case modeler_event_name::Station_Sputnik_in_range:
            res += " Station_Sputnik_in_range";
            break;

        case modeler_event_name::Station_Sputnik_out_of_range:
            res += " Station_Sputnik_out_of_range";
            break;
        case modeler_event_name::Data_transfer_start:
            res += " Data_transfer_start";
            break;
        case modeler_event_name::Data_transfer_end:
            res += " Data_transfer_end";
            break;
        };
        return res;

    }
};

std::vector<sputnik> load_sputnik_info(std::string pathname) {
    if (std::filesystem::is_directory(pathname) == false) {
        //C++ 2020 version
        //std::u8string tmp = std::filesystem::absolute(pathname).u8string();
        //C++ 2017 version
        std::string tmp = std::filesystem::absolute(pathname).u8string();
        printf("Path %s does not lead to a valid folder\n", tmp.c_str());
        exit(0);
    }
    std::vector<std::string> list_of_files;
    for (const auto& entry : std::filesystem::directory_iterator(pathname))
        list_of_files.push_back(entry.path().string());

    std::vector<sputnik> sputniks;
    for (int i = 0; i < list_of_files.size(); i++) {
        sputnik t;
        t.from_file(list_of_files[i]);
        sputniks.push_back(t);
    }
    return sputniks;
}

std::vector<station> load_station_info(std::string pathname) {
    if (std::filesystem::is_directory(pathname) == false) {
        printf("Path to stations does not lead to a valid folder\n");
        exit(0);
    }
    std::vector<station> stations;
    std::vector<std::string> list_of_files;
    for (const auto& entry : std::filesystem::directory_iterator(pathname))
        list_of_files.push_back(entry.path().string());

    for (int i = 0; i < list_of_files.size(); i++) {
        station t;
        t.from_file(list_of_files[i]);
        stations.push_back(t);
    }
    return stations;

}

struct m_sputnik_log_entry {
    double time_moment = 0;
    sputnik_status old_status;
    sputnik_status new_status;

    double dumped_data = 0;
    std::string connected_station = "";


    m_sputnik_log_entry() {}

    m_sputnik_log_entry(double TM, sputnik_status OS, sputnik_status NS, double DD, std::string CS) {
        time_moment = TM;
        old_status = OS;
        new_status = NS;
        dumped_data = DD;
        connected_station = CS;
    }
    std::string to_string() {
        std::string res;
        res = std::to_string(time_moment) + " ";
        switch (old_status) {
        case sputnik_status::SputnikIdle:
            res += "SputnikIdle ";
            break;
        case sputnik_status::SputnikDumping:
            res += "SputnikDumping ";
            break;
        case sputnik_status::Monitoring:
            res += "Monitoring ";
            break;
        case sputnik_status::Overflow:
            res += "Overflow ";
            break;
        }

        switch (new_status) {
        case sputnik_status::SputnikIdle:
            res += "SputnikIdle ";
            break;
        case sputnik_status::SputnikDumping:
            res += "SputnikDumping ";
            break;
        case sputnik_status::Monitoring:
            res += "Monitoring ";
            break;
        case sputnik_status::Overflow:
            res += "Overflow ";
            break;
        }

        res += "DD " + std::to_string(dumped_data);
        res += " " + connected_station;
        return res;
    }

};

struct m_station_log_entry {
    double time_moment = 0;
    station_status old_status = StationIdle;
    session_break reason = Switched_to_other;

    double dumped_data = 0;
    std::string connected_sputnik = "";

    m_station_log_entry() {}

    m_station_log_entry(double TM, station_status OS, session_break DS, double DD, std::string CS) {
        time_moment = TM;
        old_status = OS;
        reason = DS;
        dumped_data = DD;
        connected_sputnik = CS;
    }
};

struct m_sputnik_state {
    uint32_t num_id = UINT32_MAX;

    sputnik_status current_status = sputnik_status::SputnikIdle;
    double current_storage = 0;
    double current_status_start = 0;
    int priority = 0;
    bool updated = false;
    bool in_shadow = true;
    double next_shadow = 0;
    uint32_t sending_to = UINT32_MAX;

    double captured_total = 0;
    double transferred_total = 0;
    uint32_t s_log_size = 0;
};



struct m_sputnik {
    std::string id = "";
    uint32_t num_id = UINT32_MAX;

    double storage_size = 0;
    bool faster = false;
    double capture_speed = 0;
    double transfer_speed = 0;

    sputnik_status current_status = sputnik_status::SputnikIdle;
    double current_storage = 0;
    double current_status_start = 0;
    int priority = 0;
    bool updated = false;
    bool in_shadow = true;
    double next_shadow = 0;
    uint32_t sending_to = UINT32_MAX;

    double captured_total = 0;
    double overflow_total = 0;
    double transferred_total = 0;

    std::map<uint32_t, std::vector<modeler_event> >  sputnik_events;


    std::vector<m_sputnik_log_entry> log;
    void reset() {
        current_status = sputnik_status::SputnikIdle;
        current_storage = 0;
        current_status_start = 0;
        priority = 0;
        updated = false;
        in_shadow = true;
        next_shadow = 0;
        sending_to = UINT32_MAX;

        captured_total = 0;
        transferred_total = 0;

        log.clear();
    }

    m_sputnik_state save_state() {
        m_sputnik_state a;
        a.num_id = num_id;

        a.current_status = current_status;
        a.current_status_start = current_status_start;
        a.current_storage = current_storage;
        a.in_shadow = in_shadow;
        a.next_shadow = next_shadow;
        a.priority = priority;
        a.sending_to = sending_to;
        a.updated = updated;

        a.transferred_total = transferred_total;
        a.captured_total = captured_total;
        a.s_log_size = log.size();
        return a;
    }


    void restore_state(m_sputnik_state& a) {

        assert(num_id == a.num_id);

        current_status = a.current_status;
        current_status_start = a.current_status_start;
        current_storage = a.current_storage;
        in_shadow = a.in_shadow;
        next_shadow = a.next_shadow;
        priority = a.priority;
        sending_to = a.sending_to;
        updated = a.updated;

        transferred_total = a.transferred_total;
        captured_total = a.captured_total;

        assert(a.s_log_size >= log.size());
        if (log.size() > a.s_log_size) {
            log.resize(a.s_log_size);
        }

    }

    m_sputnik(
        sputnik& t,
        double discretization_interval,
        std::map<std::string, uint32_t>& sputnik_name_to_sputnik_id,
        std::vector<std::string>& sputnik_id_to_name,
        std::vector<std::string>& station_id_to_name)
    {
        in_shadow = true;
        id = t.id;
        num_id = sputnik_name_to_sputnik_id[id];
        current_status = SputnikIdle;
        current_storage = 0;
        storage_size = t.storage_size;

        capture_speed = t.capture_speed;
        transfer_speed = t.transfer_speed;
        sending_to = UINT32_MAX;
        next_shadow = 0;
        if (t.type == "Kinosputnik") {
            faster = true;
        }

        for (int i = 0; i < t.AreaAccess.size(); i++) {
            std::vector<double> interval = t.AreaAccess[i];
            modeler_event ev_start;

            ev_start.sputnik_id = sputnik_name_to_sputnik_id[id];
            ev_start.time_point = interval[0];
            ev_start.time_end = interval[1];
            ev_start.me_name = modeler_event_name::Sputnik_Earth_in;

            modeler_event ev_end;
            ev_end.sputnik_id = sputnik_name_to_sputnik_id[id];
            ev_end.time_point = interval[1];
            ev_end.me_name = modeler_event_name::Sputnik_Earth_out;

            uint32_t req_index_start = static_cast<uint32_t>(std::floor(ev_start.time_point / discretization_interval));

            uint32_t req_index_end = static_cast<uint32_t>(std::floor(ev_end.time_point / discretization_interval));


            if (req_index_end != req_index_start) {
                sputnik_events[req_index_start].push_back(ev_start);
                sputnik_events[req_index_end].push_back(ev_end);
            }
            else {
                printf("Skipping events due to discretization clash\n");
                printf("%s\n", ev_start.to_string(sputnik_id_to_name, station_id_to_name).c_str());
                printf("%s\n", ev_end.to_string(sputnik_id_to_name, station_id_to_name).c_str());
            }

        }
    }

    bool recompute_priority(double ct) {
        int np = 0;
        if ((current_storage == 0) || (current_status == SputnikDumping)) {
            np = 0;
        }
        else {

            double data_till_shadow = 0;
            double time_till_overflow = 0;
            if (in_shadow == false) {

                data_till_shadow = (next_shadow - ct) * capture_speed;
                time_till_overflow = (storage_size - current_storage) / transfer_speed;
                //in shadow and won't overflow
                if (current_storage + data_till_shadow <= storage_size) {
                    np = 0;
                }
                else {
                    np = 1u + static_cast<uint32_t>(std::floor(2 * time_till_overflow / (next_shadow - ct)));
                    /*if ((time_till_overflow) < ((next_shadow - ct) / 2)) {
                        //np = 2;
                        np = 2;
                    }
                    else {
                        np = 1;
                        //np = 1;
                    }*/
                }
            }
            else {
                //on a scale from one to ten how would you rate your pain?
                np = 1 + static_cast<uint32_t>(std::floor(10 * current_storage / storage_size));
                if ((faster == true) && (np > 1)) {
                    np += 2;
                }
            }
        }
        if (np != priority) {
            priority = np;
            return true;
        }
        else {
            return false;
        }
    }

};
struct m_station_state {
    uint32_t num_id = UINT32_MAX;

    station_status current_status = StationIdle;
    bool updated = false;
    double data_dumped = 0;
    double current_dumped = 0;
    double current_status_start = 0;

    uint32_t dumping_from = UINT32_MAX;
    double dumping_started_at = -1;
    double dumping_ended_at = -1;

    uint32_t m_log_size = 0;
};


struct m_station {
    std::string id = "";
    uint32_t num_id = UINT32_MAX;
    station_status current_status = StationIdle;
    bool updated = false;
    double data_dumped = 0;
    double current_dumped = 0;
    double current_status_start = 0;

    uint32_t dumping_from = UINT32_MAX;
    double dumping_started_at = -1;
    double dumping_ended_at = -1;


    std::map<double, std::vector<modeler_event> > station_events;

    std::vector<m_station_log_entry> log;

    //std::string dumping_from = "";

    void reset() {
        current_status = StationIdle;
        updated = false;
        data_dumped = 0;
        current_dumped = 0;
        current_status_start = 0;

        dumping_from = UINT32_MAX;
        dumping_started_at = -1;
        dumping_ended_at = -1;

        log.clear();
    }
    m_station_state save_state() {
        m_station_state a;
        a.num_id = num_id;

        a.current_status = current_status;
        a.updated = updated;
        a.data_dumped = data_dumped;
        a.current_dumped = current_dumped;
        a.current_status_start = current_status_start;

        a.dumping_from = dumping_from;
        a.dumping_started_at = dumping_started_at;
        a.dumping_ended_at = dumping_ended_at;
        a.m_log_size = log.size();
        return a;
    }

    void restore_state(m_station_state& a) {
        assert(num_id == a.num_id);

        current_status = a.current_status;
        updated = a.updated;
        data_dumped = a.data_dumped;
        current_dumped = a.current_dumped;
        current_status_start = a.current_status_start;

        dumping_from = a.dumping_from;
        dumping_started_at = a.dumping_started_at;
        dumping_ended_at = a.dumping_ended_at;

        assert(log.size() >= a.m_log_size);
        if (log.size() > a.m_log_size) {
            log.resize(a.m_log_size);
        }
    }


    m_station(
        station& t, double discretization_interval,
        std::map <std::string, uint32_t>& sputnik_name_to_id,
        std::map <std::string, uint32_t>& station_name_to_id,
        std::vector<std::string>& sputnik_id_to_name,
        std::vector<std::string>& station_id_to_name
    ) {
        id = t.id;
        num_id = station_name_to_id[id];
        current_status = StationIdle;
        dumping_from = UINT32_MAX;
        station_events.clear();

        for (auto& Sp : t.SatelliteAccess) {
            for (int i = 0; i < Sp.second.size(); i++) {
                std::vector<double> interval = Sp.second[i];
                modeler_event ev_in;

                ev_in.station_id = station_name_to_id[id];
                ev_in.sputnik_id = sputnik_name_to_id[Sp.first];
                ev_in.time_point = interval[0];
                ev_in.time_end = interval[1];
                ev_in.me_name = modeler_event_name::Station_Sputnik_in_range;

                modeler_event ev_out;
                ev_out.station_id = station_name_to_id[id];
                ev_out.sputnik_id = sputnik_name_to_id[Sp.first];
                ev_out.time_point = interval[1];
                ev_out.me_name = modeler_event_name::Station_Sputnik_out_of_range;

                uint32_t req_index_in = static_cast<uint32_t>(std::floor(ev_in.time_point / discretization_interval));
                uint32_t req_index_out = static_cast<uint32_t>(std::floor(ev_out.time_point / discretization_interval));

                if (req_index_in != req_index_out) {
                    station_events[interval[0]].push_back(ev_in);
                    station_events[interval[1]].push_back(ev_out);
                }
                else {
                    printf("Events skipped due to discretization clash:\n");
                    printf("%s\n", ev_in.to_string(sputnik_id_to_name, station_id_to_name).c_str());
                    printf("%s\n", ev_out.to_string(sputnik_id_to_name, station_id_to_name).c_str());
                }
            }
        }

    }
};

struct dt_ffs {
    uint32_t year;
    uint32_t month;
    uint32_t day;
    uint32_t hour;
    uint32_t minute;
    double seconds;

    std::vector<int> months_size = { 31,28,31,30,31,30, 31,30,31,31,30,31 };
    std::vector<std::string> months = { "Jan", "Feb", "Mar", "Apr",
        "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };

    dt_ffs() {
        year = 0;
        month = 0;
        day = 0;
        hour = 0;
        minute = 0;
        seconds = 0;
    }
    dt_ffs(uint32_t y, uint32_t mo, uint32_t d, uint32_t h, uint32_t mi, double s) {
        year = y;
        month = mo;
        day = d;
        hour = h;
        minute = mi;
        seconds = s;
    }

    dt_ffs(double time_sec, dt_ffs base) {

        double residual = 0;
        uint32_t ts_rounded = static_cast<uint32_t>(std::floor(time_sec));
        residual = time_sec - ts_rounded;
        // screw leap years

        year = ts_rounded / (365 * 24 * 60 * 60);
        uint32_t rem_1 = ts_rounded % (365 * 24 * 60 * 60);
        uint32_t remaining_days = rem_1 / (24 * 60 * 60);

        uint32_t cm = 0;
        while (remaining_days > months_size[cm]) {
            remaining_days -= months_size[cm];
            cm++;
        }
        month = cm;
        day = remaining_days;

        uint32_t rem_2 = ts_rounded % (24 * 60 * 60);

        hour = rem_2 / (60 * 60);

        uint32_t rem_3 = rem_2 % (60 * 60);
        minute = rem_3 / 60;

        seconds = static_cast<double>(rem_3 % 60) + residual;

        assert(base.hour == 0);
        assert(base.minute == 0);
        assert(base.seconds == 0);

        year = year + base.year;
        month = month + base.month;
        day = day + base.day;

    }
    std::string to_string() {
        std::string res;
        res = std::to_string(day) + " " + months[month - 1] + " " + std::to_string(year) + " ";
        if (hour < 10) {
            res += "0";
        }
        res += std::to_string(hour);
        res += ":";
        if (minute < 10) {
            res += "0";
        }
        res += std::to_string(minute);
        res += ":";

        if (seconds < 10) {
            res += "0";
        }
        uint32_t sv = static_cast<uint32_t>(std::floor(seconds));
        uint32_t residual = static_cast<uint32_t>(std::round((seconds - sv) * 1000));
        res += std::to_string(sv);
        res += ".";
        std::string residual_str = std::to_string(residual);
        while (residual_str.size() < 3) {
            residual_str = "0" + residual_str;
        }
        res += residual_str;


        return res;
    }


};

struct station_datapoint {
    double time_start = 0.0;
    double time_end = 0.0;
    double duration = 0.0;
    std::string sputnik = "";
    std::string station = "";
    double data_sent = 0.0;
    std::string print_sdp() {
        std::string r = sputnik + " -> " + station + " " + std::to_string(time_start) + " :: " + std::to_string(time_end) +
            " (" + std::to_string(duration) + ") : " + std::to_string(data_sent);
        return r;
    }
};



void print_station(std::string& station_name, std::vector<station_datapoint>& sol, std::string& filename) {
    std::ofstream outfile;
    outfile.open(filename.c_str());
    outfile << station_name << std::endl;
    outfile << "-------------------------" << std::endl;
    outfile << "Access * Start Time (UTCG) * Stop Time (UTCG) * Duration (sec) * Sat * Data (Mbytes)" << std::endl;
    dt_ffs base_time(2027, 6, 1, 0, 0, 0);
    uint32_t access_counter = 1;
    for (int i = 0; i < sol.size(); i++) {
        std::string r = std::to_string(access_counter) + "\t" + dt_ffs(sol[i].time_start, base_time).to_string();
        r += "\t" + dt_ffs(sol[i].time_end, base_time).to_string() + "\t" + std::to_string(sol[i].duration) + "\t";
        r += sol[i].sputnik + "\t" + std::to_string(sol[i].data_sent);
        outfile << r << std::endl;
        access_counter++;
    }
}

void print_solution(std::map <std::string, std::vector<station_datapoint> >& Solution) {

    std::string solution_dir = "./solution";
    std::filesystem::create_directories(solution_dir);

    for (auto& t : Solution) {
        std::string station_name = t.first;
        std::vector<station_datapoint>& station_data = t.second;
        std::string fn = solution_dir + "//" + station_name + ".res";
        print_station(station_name, station_data, fn);
    }
}

//using station_datapoint = std::tuple<double, double, double, std::string, double>;
/*
static std::vector<station_datapoint> extract_solution(m_station& obs) {

    std::vector<station_datapoint> station_data;

    uint32_t access_counter = 1;
    double interval_start = 0;
    double interval_end = 0;
    double data_sent = 0;
    std::string sputnik_from = "";
    double total_dumped = 0;


    //outfile << "Access * Start Time (UTCG) * Stop Time (UTCG) * Duration (sec) * Sat * Data (Mbytes)" << std::endl;
    for (int i = 0; i < obs.log.size(); i++) {
        m_station_log_entry& m = obs.log[i];
        if (m.reason == Start_dumping) {
            assert(interval_start == 0.0);
            assert(interval_end == 0.0);
            assert(data_sent == 0.0);
            assert(sputnik_from == "");
            interval_start = m.time_moment;
            sputnik_from = m.connected_sputnik;
        }
        if ((m.reason == Out_of_range) || (m.reason == Switched_to_other) || (m.reason == Dumped_all_data) || (m.reason == Delay_in_shadow) || (m.reason == OOM)) {
            assert(sputnik_from == m.connected_sputnik);
            interval_end = m.time_moment;
            data_sent = m.dumped_data;
            double duration = interval_end - interval_start;
            station_datapoint t;
            t.time_start = double(interval_start);
            t.time_end = double(interval_end);
            t.duration = double(duration);
            t.sputnik = sputnik_from;
            t.station = obs.id;
            t.data_sent = data_sent*1000;
            station_data.push_back(t);

            interval_start = 0;
            interval_end = 0;
            sputnik_from = "";
            data_sent = 0;
        }
    }
    return station_data;
}
*/

/*

static void dump_solution_to_file(m_station &obs, std::string filename) {
    std::ofstream outfile;
    outfile.open(filename.c_str());
    outfile << obs.id << std::endl;
    outfile << "-------------------------" << std::endl;
    uint32_t access_counter = 1;
    double interval_start = 0;
    double interval_end = 0;
    double data_sent = 0;
    std::string sputnik_from = "";
    double total_dumped = 0;


    outfile << "Access * Start Time (UTCG) * Stop Time (UTCG) * Duration (sec) * Sat * Data (Mbytes)" << std::endl;
    dt_ffs base_time(2027, 6, 1, 0, 0, 0);
    for (int i = 0; i < obs.log.size(); i++) {
        m_station_log_entry& m = obs.log[i];
        if (m.reason == Start_dumping) {
            assert(interval_start == 0.0);
            assert(interval_end == 0.0);
            assert(data_sent == 0.0);
            assert(sputnik_from == "");
            interval_start = m.time_moment;
            sputnik_from = m.connected_sputnik;
        }
        if ((m.reason == Out_of_range)||(m.reason == Switched_to_other)||(m.reason == Dumped_all_data)||(m.reason == Delay_in_shadow) || (m.reason == OOM)) {
            assert(sputnik_from == m.connected_sputnik);
            interval_end = m.time_moment;
            data_sent = m.dumped_data;
            double duration = interval_end - interval_start;

            std::string r = std::to_string(access_counter) + "\t" + dt_ffs(interval_start, base_time).to_string();
            r += "\t" + dt_ffs(interval_end, base_time).to_string() + "\t" + std::to_string(duration) + "\t";
            r += sputnik_from + "\t" + std::to_string(data_sent*1000);
            total_dumped += data_sent;

            outfile << r << std::endl;
            access_counter++;
            interval_start = 0.0;
            interval_end = 0.0;
            sputnik_from = "";
            data_sent = 0.0;
        }
        //m_station_log_entry so(tm, co.current_status, Start_dumping, 0 , cs.id);

        // m_station_log_entry so(tm, co.current_status, DES, data_dumped, cs.id);
    }
    outfile.close();
    // printf("%s dumped %f data in total\n", obs.id, total_dumped);


}
*/

bool compare_modeler_events(modeler_event& a, modeler_event& b) {
    return (a.time_point < b.time_point);
}




struct modeler_decision {
    uint32_t index = 0;
    double time_moment = -1;
    uint32_t station = UINT32_MAX;
    uint32_t sputnik = UINT32_MAX;
};

struct modeler_state {
    std::map <std::string, std::vector<station_datapoint> > SOL_state;
    std::vector<m_station_state> st_states;
    std::vector<m_sputnik_state> sp_states;

    double time_moment = 0;
    uint32_t current_index = UINT32_MAX;

    double total_time_monitoring = 0;
    double total_time_overflow = 0;
    double total_time_dumping = 0;
    double total_time_dumping_instead_of_monitoring = 0;
    double total_data_captured = 0;
    double total_data_sent = 0;
    double perf_metric = 0;
    double sytem_time_no_overflow = 0;

    //iteration-specific

    std::vector<std::vector<std::pair<double, double> > > in_range_of_station;
    std::vector < std::vector<std::pair<double, double> > >  in_range_of_sputnik;

    std::vector<bool> need_update_sputnik;
    std::vector<bool> need_update_station;

    //std::map<std::string, bool> sputniks_observing_area;


    bool in_overflow_start = false;
    bool in_overflow_end = false;
    double overflow_start = 0;
    double overflow_end = 0;

    std::vector<modeler_decision> decisions;

};

enum iterate_mode {
    baseline,
    random_best,
    random_random
};


struct modeler {
    std::map <std::string, std::vector<station_datapoint> > SOL;

    std::vector<m_sputnik> m_sputniks;
    std::vector<m_station> m_stations;
    std::map<std::string, uint32_t> sputnik_name_to_id;
    std::map<std::string, uint32_t> station_name_to_id;


    std::vector<std::string> sputnik_id_to_name;
    std::vector<std::string> station_id_to_name;


    double ds_interval = 1.0;
    uint32_t max_time = 0;
    double total_time_monitoring = 0;
    double total_time_overflow = 0;
    double total_time_dumping = 0;
    double total_time_dumping_instead_of_monitoring = 0;
    double total_data_captured = 0;
    double total_data_sent = 0;
    double perf_metric = 0;
    double sytem_time_no_overflow = 0;


    bool Enable_logging = false;


    //aux structures for iterating
    uint32_t max_time_moments = 0;
    double time_step = 0;

    uint32_t current_index = UINT32_MAX;
    std::vector<std::vector<std::pair<double, double> > > in_range_of_station;
    std::vector < std::vector<std::pair<double, double> > >  in_range_of_sputnik;

    std::vector<bool> need_update_sputnik;
    std::vector<bool> need_update_station;

    //std::map<std::string, bool> sputniks_observing_area;


    bool in_overflow_start = false;
    bool in_overflow_end = false;
    double overflow_start = 0;
    double overflow_end = 0;

    std::vector<modeler_decision> decisions;
    void reset() {
        for (int i = 0; i < m_sputniks.size(); i++) {
            m_sputniks[i].reset();
        }
        for (int i = 0; i < m_stations.size(); i++) {
            m_stations[i].reset();
        }

        total_time_monitoring = 0;
        total_time_overflow = 0;
        total_time_dumping = 0;
        total_time_dumping_instead_of_monitoring = 0;
        total_data_captured = 0;
        total_data_sent = 0;
        perf_metric = 0;
        sytem_time_no_overflow = 0;

        current_index = UINT32_MAX;
        in_range_of_station.clear();
        in_range_of_sputnik.clear();

        need_update_sputnik.clear();
        need_update_station.clear();

        //std::map<std::string, bool> sputniks_observing_area;


        in_overflow_start = false;
        in_overflow_end = false;
        overflow_start = 0;
        overflow_end = 0;

        SOL.clear();

    }

    modeler_state save_state(double time_moment) {
        modeler_state res;
        res.SOL_state = SOL;
        res.current_index = current_index;
        res.time_moment = time_moment;

        res.total_time_monitoring = total_time_monitoring;
        res.total_time_overflow = total_time_overflow;
        res.total_time_dumping = total_time_dumping;
        res.total_time_dumping_instead_of_monitoring = total_time_dumping_instead_of_monitoring;
        res.total_data_captured = total_data_captured;
        res.total_data_sent = total_data_sent;
        res.perf_metric = perf_metric;
        res.sytem_time_no_overflow = sytem_time_no_overflow;

        for (uint32_t i = 0; i < m_sputniks.size(); i++) {
            m_sputnik_state a = m_sputniks[i].save_state();
            res.sp_states.push_back(a);
        }

        for (uint32_t i = 0; i < m_stations.size(); i++) {
            m_station_state a = m_stations[i].save_state();
            res.st_states.push_back(a);
        }


        //  uint32_t current_index = UINT32_MAX;

        res.in_range_of_station = in_range_of_station;
        res.in_range_of_sputnik = in_range_of_sputnik;

        res.need_update_sputnik = need_update_sputnik;
        res.need_update_station = need_update_station;

        //std::map<std::string, bool> sputniks_observing_area;


        res.in_overflow_start = in_overflow_start;
        res.in_overflow_end = in_overflow_end;
        res.overflow_start = overflow_start;
        res.overflow_end = overflow_end;

        res.decisions = decisions;
        return res;
    }
    void restore_state(modeler_state& a, double tm) {
        current_index = a.current_index;
        tm = a.time_moment;
        SOL = a.SOL_state;
        total_time_monitoring = a.total_time_monitoring;
        total_time_overflow = a.total_time_overflow;
        total_time_dumping = a.total_time_dumping;
        total_time_dumping_instead_of_monitoring = a.total_time_dumping_instead_of_monitoring;
        total_data_captured = a.total_data_captured;
        total_data_sent = a.total_data_sent;
        perf_metric = a.perf_metric;
        sytem_time_no_overflow = a.sytem_time_no_overflow;

        assert(a.sp_states.size() == m_sputniks.size());
        for (uint32_t i = 0; i < a.sp_states.size(); i++) {
            m_sputniks[i].restore_state(a.sp_states[i]);
        }

        for (uint32_t i = 0; i < a.st_states.size(); i++) {
            m_stations[i].restore_state(a.st_states[i]);
        }

        //restore SOL state to relevant time_point


        //  uint32_t current_index = UINT32_MAX;
        in_range_of_station = a.in_range_of_station;
        in_range_of_sputnik = a.in_range_of_sputnik;

        need_update_sputnik = a.need_update_sputnik;
        need_update_station = a.need_update_station;

        //std::map<std::string, bool> sputniks_observing_area;


        in_overflow_start = a.in_overflow_start;
        in_overflow_end = a.in_overflow_end;
        overflow_start = a.overflow_start;
        overflow_end = a.overflow_end;

        decisions = a.decisions;

    }


    bool monitor(m_sputnik& cs, double time_period_start, double time_period_end) {

        double data_accumulated = (time_period_end - time_period_start) * cs.capture_speed;
        bool res = true;
        if ((cs.current_storage + data_accumulated) < cs.storage_size) {
            cs.captured_total += data_accumulated;

            cs.current_storage += data_accumulated;
            total_data_captured += data_accumulated;
            total_time_monitoring += (time_period_end - time_period_start);
        }
        else {
            //calculate the exact time when the overflow occurs
            double t_overflow = time_period_start + (cs.storage_size - cs.current_storage) / cs.capture_speed;

            total_data_captured += (cs.storage_size - cs.current_storage);
            cs.current_storage = cs.storage_size;
            cs.captured_total += (cs.storage_size - cs.current_storage);

            //should we add some tolerance here? 
            assert(t_overflow <= time_period_end);
            cs.current_status = Overflow;
            cs.current_status_start = t_overflow;
            res = false;

            total_time_monitoring += (t_overflow - time_period_start);
            //total_time_overflow += (time_period_end - t_overflow);

            if (Enable_logging) {
                m_sputnik_log_entry sl(t_overflow, Monitoring, Overflow, 0, "");
                cs.log.push_back(sl);
            }
        }
        cs.recompute_priority(time_period_end);
        return res;
    }

    void dump(m_sputnik& cs, double time_period_start, double time_period_end) {

        /*if ((cs.current_storage == 0.0) && (time_period_start != time_period_end)) {
            printf("%s\n", cs.id.c_str());
            for (int i = 0; i < cs.log.size(); i++) {
                printf("%s \n", cs.log[i].to_string().c_str());
            }
            m_station& ffso = m_stations[station_id_map[cs.sending_to]];

            printf("%f %f\n",cs.current_storage, ffso.current_dumped);
            printf("Time %f\n", time_period_start);
        }*/

        assert((cs.current_storage > 0.0) || (time_period_start == time_period_end));
        assert(cs.sending_to != UINT32_MAX);

        m_station& co = m_stations[cs.sending_to];


        double data_dumped_current_period = (cs.transfer_speed) * (time_period_end - time_period_start);


        assert(data_dumped_current_period <= cs.current_storage + 0.0001);

        cs.transferred_total += data_dumped_current_period;
        co.current_dumped += data_dumped_current_period;
        co.data_dumped += data_dumped_current_period;

        cs.current_storage -= data_dumped_current_period;
        if (std::abs(cs.current_storage) < 0.001) {
            cs.current_storage = 0.0;
        }
        total_data_sent += data_dumped_current_period;

        total_time_dumping += (time_period_end - time_period_start);
        if (cs.in_shadow == false) {
            total_time_dumping_instead_of_monitoring += (time_period_end - time_period_start);
        }
        cs.recompute_priority(time_period_end);
    }


    void stop_dumping(m_sputnik& cs, m_station& co, double  time_point, session_break DES) {


        //stop dumping and update sputnik log    
        double data_dumped = co.current_dumped;

        //m_sputnik_log_entry(uint32_t &TM, sputnik_status &OS, sputnik_status &NS, double &DD, std::string &CS) {        

        assert(cs.sending_to == co.num_id);
        assert(co.dumping_from == cs.num_id);

        if (Enable_logging) {
            m_sputnik_log_entry sl(time_point, cs.current_status, SputnikIdle, data_dumped, co.id);
            cs.log.push_back(sl);
        }
        cs.current_status = SputnikIdle;
        cs.sending_to = UINT32_MAX;
        cs.current_status_start = time_point;



        cs.recompute_priority(time_point);

        if (Enable_logging) {
            m_station_log_entry so(time_point, co.current_status, DES, data_dumped, cs.id);
            co.log.push_back(so);
        }
        co.dumping_ended_at = time_point;
        station_datapoint t;
        t.data_sent = data_dumped ;
        t.sputnik = cs.id;
        t.station = co.id;
        t.time_start = co.dumping_started_at;
        t.time_end = co.dumping_ended_at;
        t.duration = t.time_end - t.time_start;

        SOL[co.id].push_back(t);

        co.dumping_started_at = -1;
        co.dumping_ended_at = -1;
        co.dumping_from = UINT32_MAX;
        co.current_dumped = 0;
        co.current_status = StationIdle;
        co.current_status_start = time_point;


    }

    void start_dumping(m_sputnik& cs, m_station& co, double& tm) {
        //stop dumping and update sputnik log    

        //m_sputnik_log_entry(uint32_t &TM, sputnik_status &OS, sputnik_status &NS, double &DD, std::string &CS) {        


        assert(cs.sending_to == UINT32_MAX);
        assert(co.dumping_from == UINT32_MAX);

        assert(co.dumping_started_at == -1.0);
        assert(co.dumping_ended_at == -1.0);
        co.dumping_started_at = tm;

        if (Enable_logging) {
            m_sputnik_log_entry sl(tm, cs.current_status, SputnikDumping, cs.current_storage, co.id);
            cs.log.push_back(sl);
        }
        cs.sending_to = co.num_id;
        cs.current_status = SputnikDumping;
        cs.current_status_start = tm;
        cs.recompute_priority(tm);

        if (Enable_logging) {
            m_station_log_entry so(tm, co.current_status, Start_dumping, 0, cs.id);
            co.log.push_back(so);
        }
        co.dumping_from = cs.num_id;
        co.current_dumped = 0;
        co.current_status = StationDumping;
        co.current_status_start = tm;

    }


    modeler(std::vector<sputnik> sputniks, std::vector<station> stations, double Discretization_interval, int Maximum_time) {
        ds_interval = Discretization_interval;

        max_time = Maximum_time;
        for (int i = 0; i < sputniks.size(); i++) {
            sputnik_name_to_id[sputniks[i].id] = i;
            sputnik_id_to_name.push_back(sputniks[i].id);
        }

        for (int i = 0; i < stations.size(); i++) {
            station_name_to_id[stations[i].id] = i;
            station_id_to_name.push_back(stations[i].id);
        }

        for (int i = 0; i < sputniks.size(); i++) {
            m_sputnik t(sputniks[i], ds_interval, sputnik_name_to_id, sputnik_id_to_name, station_id_to_name);
            m_sputniks.push_back(t);
        }
        uint32_t cnttotal = 0;
        uint32_t cntgeq2 = 0;
        for (int i = 0; i < stations.size(); i++) {
            m_station t(stations[i], ds_interval, sputnik_name_to_id, station_name_to_id, sputnik_id_to_name, station_id_to_name);
            m_stations.push_back(t);

            for (auto& st_e : t.station_events) {
                std::vector<modeler_event>& tmp_me = st_e.second;
                if (tmp_me.size() > 1) {
                    cntgeq2++;
                }
                cnttotal++;
                for (int j = 0; j < tmp_me.size(); j++) {
                    m_sputnik& cs = m_sputniks[tmp_me[j].sputnik_id];

                    //figure out where to put it with respect to discretization step
                    //normally with ds = 1 it would go to M_events[floor(time_point)]
                    //to account for discretization, apparently it should go to M_events[floor(time_point*ds_step)]
                    uint32_t req_index = static_cast<uint32_t>(std::floor(tmp_me[j].time_point / ds_interval));
                    cs.sputnik_events[req_index].push_back(tmp_me[j]);
                }
            }
        }
        //printf("Count of >1 entries %u out of %u\n", cntgeq2, cnttotal);
        //sort entries
        for (int i = 0; i < m_sputniks.size(); i++) {
            m_sputnik& cs = m_sputniks[i];
            for (auto& it : cs.sputnik_events) {
                std::sort(it.second.begin(), it.second.end(), compare_modeler_events);
            }
        }
    }

    inline void iterate_first_part(uint32_t& i, double& time_period_start, double& time_period_end) {
        for (uint32_t j = 0; j < m_sputniks.size(); j++) {
            //FIRST
            //Finalize all changes that occur in this time period:
            // -- If sputnik stops monitoring due to going out of range
            // -- If sputnik stops monitoring due to overflow
            // -- If sputnik stops dumping due to going out of range
            // -- If sputnik stops dumping to start monitoring (delay in shadow)
            // -- If sputnik stops dumping due to having dumped all data



            //determine whether we need an update
            //either due to new events or a change in status
            m_sputnik& cs = m_sputniks[j];
            auto ev_vec = cs.sputnik_events.find(i);
            if (ev_vec != cs.sputnik_events.end()) {
                std::vector<modeler_event> cur_sp_events = ev_vec->second;
                for (modeler_event& cur_ev : cur_sp_events) {
                    if (cur_ev.me_name == modeler_event_name::Sputnik_Earth_in) {
                        //sputniks_observing_area[cs.id] = true;
                        cs.in_shadow = false;
                        cs.next_shadow = cur_ev.time_end;
                        // If idle need to start monitoring                            

                        if (cs.current_status == SputnikIdle) {
                            cs.current_status = Monitoring;
                            cs.current_status_start = cur_ev.time_point;
                            assert(cs.sending_to == UINT32_MAX);
                            if (Enable_logging) {
                                m_sputnik_log_entry sl(cur_ev.time_point, SputnikIdle, Monitoring, cs.current_storage, "");
                                cs.log.push_back(sl);
                            }
                            cs.updated = true;
                        }
                        // If dumping need to decide whether to stop dumping

                        //clash here it seems 

                        if (cs.current_status == SputnikDumping) {
                            //decide whether we can stop dumping and start monitoring
                            if ((cur_ev.time_point + (cs.storage_size - cs.current_storage) / cs.transfer_speed) > cs.next_shadow) {

                                double time_till_dump_all = cs.current_storage / cs.transfer_speed;
                                /*                   if (time_till_dump_all < 0.0001) {
                                                        printf("%f \n", time_till_dump_all);

                                                    }*/
                                double pivot = time_period_start + time_till_dump_all;

                                if (pivot <= cur_ev.time_point) {
                                    //dumped all data
                                    dump(cs, time_period_start, pivot);
                                    stop_dumping(cs, m_stations[cs.sending_to], pivot, Dumped_all_data);                                    
                                }
                                else{
                                    dump(cs, time_period_start, cur_ev.time_point);                            
                                    stop_dumping(cs, m_stations[cs.sending_to], cur_ev.time_point, Delay_in_shadow);
                                }
                                cs.current_status = Monitoring;
                                if (Enable_logging) {
                                    m_sputnik_log_entry sl(cur_ev.time_point, SputnikIdle, Monitoring, cs.current_storage, "");
                                    cs.log.push_back(sl);
                                }
                                cs.current_status_start = cur_ev.time_point;

                                //monitor(cs, cur_ev.time_point, time_period_end);

                                cs.updated = true;
                            }
                        }
                    }

                    if (cur_ev.me_name == modeler_event_name::Sputnik_Earth_out) {
                        //sputniks_observing_area[cs.id] = false;

                        cs.updated = true;
                        cs.in_shadow = true;

                        cs.next_shadow = 0;
                        if ((cs.current_status == Monitoring)||(cs.current_status == Overflow)) {
                            monitor(cs, time_period_start, cur_ev.time_point);                            
                            sputnik_status new_status = SputnikIdle;                            
                            cs.current_status_start = cur_ev.time_point;
                            assert(cs.sending_to == UINT32_MAX);
                            if (Enable_logging) {
                                if (cs.current_status == Overflow) {
                                    cs.overflow_total += cur_ev.time_point - time_period_start;
                                }
                                m_sputnik_log_entry sl(cur_ev.time_point, cs.current_status, SputnikIdle, cs.current_storage, "");
                                cs.current_status = SputnikIdle;
                                cs.log.push_back(sl);

                            }

                            cs.updated = true;
                        }
                    }

                    if (cur_ev.me_name == modeler_event_name::Station_Sputnik_in_range) {

                        in_range_of_station[cur_ev.station_id][cs.num_id].first = cur_ev.time_point;
                        in_range_of_station[cur_ev.station_id][cs.num_id].second = cur_ev.time_end;

                        in_range_of_sputnik[cs.num_id][cur_ev.station_id].first = cur_ev.time_point;
                        in_range_of_sputnik[cs.num_id][cur_ev.station_id].second = cur_ev.time_end;
                    }

                    if (cur_ev.me_name == modeler_event_name::Station_Sputnik_out_of_range) {



                        in_range_of_station[cur_ev.station_id][cs.num_id] = { 0, 0 };
                        in_range_of_sputnik[cs.num_id][cur_ev.station_id] = { 0, 0 };

                        //need to stop dumping if we did and update station and sputnik status if we stop
                        if ((cs.current_status == SputnikDumping) && (cs.sending_to == cur_ev.station_id)) {
                            dump(cs, time_period_start, cur_ev.time_point);
                            stop_dumping(cs, m_stations[cur_ev.station_id], cur_ev.time_point, Out_of_range);
                            cs.updated = true;
                        }
                    }
                }
            }
        }
        //Next we check whether sputniks stop due to overflow or due to having dumped all data
        for (uint32_t j = 0; j < m_sputniks.size(); j++) {
            m_sputnik& cs = m_sputniks[j];
            if (cs.current_status == SputnikDumping) {
                double time_till_dump_all = cs.current_storage / cs.transfer_speed;
                /*                   if (time_till_dump_all < 0.0001) {
                                        printf("%f \n", time_till_dump_all);

                                    }*/
                double pivot = time_period_start + time_till_dump_all;

                if (pivot <= time_period_end) {
                    //dumped all data
                    dump(cs, time_period_start, pivot);
                    stop_dumping(cs, m_stations[cs.sending_to], pivot, Dumped_all_data);
                    if (pivot < time_period_end) {
                        cs.updated = true;
                        need_update_sputnik[j] = true;
                    }
                }
            }
        }

    }
    inline void iterate_third_part(uint32_t& i, double& time_period_start, double& time_period_end) {
        for (int j = 0; j < m_sputniks.size(); j++) {
            m_sputnik& sp = m_sputniks[j];
            if (sp.current_status == SputnikDumping) {
                double tm_start = time_period_start;
                if (sp.current_status_start > tm_start) {
                    tm_start = sp.current_status_start;
                }
                dump(sp, tm_start, time_period_end);
            }
            if (sp.current_status == Monitoring) {
                double tm_start = time_period_start;
                if (sp.current_status_start > tm_start) {
                    tm_start = sp.current_status_start;
                }
                monitor(sp, tm_start, time_period_end);
            }
            if (sp.current_status == Overflow) {
                double tm_start = time_period_start;
                if (sp.current_status_start > tm_start) {
                    tm_start = sp.current_status_start;
                }
                sp.overflow_total += (time_period_end - tm_start);

                total_time_overflow += (time_period_end - tm_start);
            }

            if (sp.current_status == SputnikIdle) {
                if (sp.in_shadow == false) {
                    double tm_start = time_period_start;
                    if (sp.current_status_start > tm_start) {
                        tm_start = sp.current_status_start;
                    }
                    assert(sp.sending_to == UINT32_MAX);
                    sp.current_status = Monitoring;
                    if (Enable_logging) {
                        m_sputnik_log_entry sl(tm_start, SputnikIdle, Monitoring, sp.current_storage, "");
                        sp.log.push_back(sl);
                    }
                    monitor(sp, tm_start, time_period_end);
                }
            }
        }

        for (uint32_t j = 0; j < m_sputniks.size(); j++) {
            if (m_sputniks[j].current_status == Overflow) {
                in_overflow_end = true;
            }
        }

        if (!in_overflow_start && !in_overflow_end) {
            sytem_time_no_overflow += (time_period_end - time_period_start);
        }
        in_overflow_start = false;
        in_overflow_end = false;
    }
    uint32_t iterate(iterate_mode IM) {
        uint32_t num_decisions = 0;
        uint32_t i = current_index;

        double time_period_start = (double)i * time_step;
        double time_period_end = time_period_start + time_step;
        //Sputnik_Earth_in -> we need to decide for this sputnik whether it 
        //starts monitoring (because it was idle and was not dumping) or not

        //Sputnik_Earth_out -> we need to decide for this sputnik whether it 
        //stops monitoring (because it was not dumping and was not overflowing) or not


        for (uint32_t j = 0; j < m_sputniks.size(); j++) {
            if (m_sputniks[j].current_status == Overflow) {
                in_overflow_start = true;
            }
            m_sputniks[j].updated = false;
            need_update_sputnik[j] = false;
        }
        for (uint32_t j = 0; j < m_stations.size(); j++) {
            m_stations[j].updated = false;
            need_update_station[j] = false;
        }

        iterate_first_part(i, time_period_start, time_period_end);


        //All previous actions should be finalized and all sputniks and stations free to choose what's up next

        for (int j = 0; j < m_stations.size(); j++) {
            m_station& obs = m_stations[j];
            if (obs.current_status == StationIdle) {

                //make the list of possible alternatives and choose the one with top priority.
                //TODO:modify for the general case
                uint32_t cur_sp = UINT32_MAX;
                uint32_t prio = 0;
                uint32_t number_of_alternatives = 0;
                std::vector<uint32_t> all_alts;
                std::map<uint32_t, std::vector<uint32_t>> alts;
                for (int h = 0; h < m_sputniks.size(); h++) {
                    if ((in_range_of_station[obs.num_id][h].first != 0) && (in_range_of_station[obs.num_id][h].second != 0)) {
                        number_of_alternatives++;
                     
                        all_alts.push_back(h);
                        alts[m_sputniks[h].priority].push_back(h);
                        if (m_sputniks[h].priority > prio) {
                            cur_sp = h;
                            prio = m_sputniks[h].priority;
                        }
                    }
                }

                if (cur_sp != UINT32_MAX) {
                    //need to carefully ensure that the time moment is proper

                    //heuristically choose the best one from alts[prio];
                    if (alts[prio].size() > 1) {
                        num_decisions++;
                        if (IM == iterate_mode::random_best) {
                            uint32_t a = lfsr113_Bits();
                            cur_sp = alts[prio][a % (alts[prio].size())];
                        }
                        if (IM == iterate_mode::random_random) {
                            uint32_t a = lfsr113_Bits();
                            cur_sp = all_alts[a % (all_alts.size())];
                        }
                        //   cur_sp = alts[prio][1];
                    }
                }

                if (cur_sp != UINT32_MAX) {
                    //need to carefully ensure that the time moment is proper

                    //heuristically choose the best one from alts[prio];
                    if (alts[prio].size() > 1) {
                        if (IM == iterate_mode::random_best) {
                            uint32_t a = lfsr113_Bits();
                            cur_sp = alts[prio][a % (alts[prio].size())];
                        }
                        if (IM == iterate_mode::random_random) {
                            uint32_t a = lfsr113_Bits();
                            cur_sp = all_alts[a % (all_alts.size())];
                        }
                        //   cur_sp = alts[prio][1];
                    }



                    m_sputnik& sp = m_sputniks[cur_sp];

                    assert(sp.current_status != SputnikDumping);
                    std::pair<double, double> tmp = in_range_of_station[obs.num_id][sp.num_id];

                    double correct_tm = tmp.first;
                    if (correct_tm < time_period_start) {
                        correct_tm = time_period_start;
                    }

                    //we need to take into account when the sputnik became idle
                    if (correct_tm < sp.current_status_start) {
                        correct_tm = sp.current_status_start;
                    }

                    //we need to take into account when the station became idle
                    if (correct_tm < obs.current_status_start) {
                        correct_tm = obs.current_status_start;
                    }
                    assert(correct_tm <= time_period_end);

                    //this is a dirty fix
                    if (sp.current_status == Overflow) {
                        total_time_overflow += correct_tm - (std::max(time_period_start, sp.current_status_start));
                    }
                    modeler_decision td;
                    td.index = current_index;
                    td.sputnik = sp.num_id;
                    td.station = obs.num_id;
                    td.time_moment = correct_tm;
                    if (alts[prio].size() > 1) {
                        decisions.push_back(td);
                    }

                    start_dumping(sp, obs, correct_tm);

                }
            }
        }

        // finalize all
        iterate_third_part(i, time_period_start, time_period_end);

        current_index++;
        return num_decisions;

    }

  
     void run(bool verbose = true) {
        std::chrono::steady_clock::time_point modeling_start = std::chrono::steady_clock::now();

        in_range_of_station.resize(m_stations.size());
        in_range_of_sputnik.resize(m_sputniks.size());
        for (uint32_t i = 0; i < m_stations.size(); i++) {
            for (uint32_t j = 0; j < m_sputniks.size(); j++) {
                std::pair<double, double> tmp;
                tmp.first = 0.0;
                tmp.second = 0.0;
                in_range_of_station[i].push_back(tmp);
            }
        }

        for (uint32_t i = 0; i < m_sputniks.size(); i++) {
            for (uint32_t j = 0; j < m_stations.size(); j++) {
                std::pair<double, double> tmp;
                tmp.first = 0.0;
                tmp.second = 0.0;
                in_range_of_sputnik[i].push_back(tmp);
            }
        }


        max_time_moments = static_cast<uint32_t>(std::ceil(static_cast<double>(max_time) / ds_interval));
        need_update_sputnik.resize(m_sputniks.size(), false);
        need_update_station.resize(m_stations.size(), false);


        time_step = ds_interval;

        in_overflow_start = false;
        in_overflow_end = false;
        overflow_start = 0;
        overflow_end = 0;

        current_index = 0;
        std::vector<uint32_t> m;
        for (uint32_t i = 0; i < 1000; i++) {
            uint32_t t = lfsr113_Bits() % max_time_moments;
            m.push_back(t);
        }
        std::sort(m.begin(), m.end());
        bool b = false;
        modeler_state ff;

        std::vector<double> accumulated_per_day(14);
        std::vector<double> dumped_per_day(14);
        
        std::vector<std::vector<double>> sp_transferred_last(14, std::vector<double>(m_sputniks.size()));
        std::vector<std::vector<double>> sp_captured_last(14, std::vector<double>(m_sputniks.size()));
        std::vector<std::vector<double>> sp_overflow_last(14, std::vector<double>(m_sputniks.size()));


        std::vector<std::vector<double>> st_transferred_last(14,std::vector<double>(m_stations.size()));

        
        uint32_t day = static_cast<uint32_t>(std::floor((double)((24 * 60 * 60) / ds_interval)));
        uint32_t k = 1;
        while (current_index < max_time_moments) {
            if (verbose) {
                if ((current_index > 0) && (current_index % static_cast<uint32_t>(std::round(max_time_moments / 100.0)) == 0)) {
                    printf("\n Current progress: %i %f\n", current_index / static_cast<uint32_t>(std::round(max_time_moments / 100.0)), total_data_sent);
                }
                if (current_index == day*k) {
                    for (uint32_t h = 0; h < m_sputniks.size(); h++) {
                        sp_captured_last[k][h] = m_sputniks[h].captured_total;
                        sp_transferred_last[k][h] = m_sputniks[h].transferred_total;
                        sp_overflow_last[k][h] = m_sputniks[h].overflow_total;
                    }
                    for (uint32_t h = 0; h < m_stations.size(); h++) {
                        st_transferred_last[k][h] = m_stations[h].data_dumped;
                    }
                    k++;
                }
            }
            iterate(baseline);            
            //iterate(random_best);
        }
        
        for (uint32_t g = 0; g < m_sputniks.size(); g++){
            printf("=================================================\n");
            printf("Day by day statistics for %s\n", m_sputniks[g].id.c_str());
            for (uint32_t h = 1; h < 14; h++) {
                printf("Day %u captured %f, sent %f, in overflow %f seconds\n", h,
                    (sp_captured_last[h][g]- sp_captured_last[h-1][g])/1024,(sp_transferred_last[h][g] - sp_transferred_last[h-1][g])/1024,
                    (sp_overflow_last[h][g]- sp_overflow_last[h-1][g]));
            }
        }
        for (uint32_t g = 0; g < m_stations.size(); g++) {
            printf("Detailed statistics for %s\n", m_stations[g].id.c_str());
            for (uint32_t h = 1; h < 14; h++) {
                printf("Day %u recieved %f Gb of data\n", h, (st_transferred_last[h][g]- st_transferred_last[h-1][g])/1024);
            }
        }

        printf("Total data dumped per day\n");
        double total_dumped_compute = 0;
        for (uint32_t h = 1; h < 14; h++) {
            double sputnik_sent = 0;
            
            for (uint32_t g = 0; g < m_sputniks.size(); g++) {
                sputnik_sent += (sp_transferred_last[h][g]- sp_transferred_last[h-1][g]);
            }

            double station_received = 0;
            for (uint32_t g = 0; g < m_stations.size(); g++) {
                station_received += (st_transferred_last[h][g]- st_transferred_last[h-1][g]);
            }
            //assert(sputnik_sent == station_received);
            printf("Day %u %f Gb\n", h, station_received / 1024);
            total_dumped_compute += station_received / 1024;

        }

        /*double cm = 0;
        for (uint32_t h = 0; h < m_stations.size(); h++) {
            cm += m_stations[h].data_dumped;
        }
        printf("cm  %f\n", cm / 1024);
        double ct = 0;
        for (uint32_t h = 0; h < m_sputniks.size(); h++) {
            ct += m_sputniks[h].transferred_total;
        }
        printf("ct  %f\n", ct/1024 );
        */
        printf("Total dumped %f Gb\n", total_dumped_compute);
        

        printf("\n");

        printf("Modeling ended\n");


        std::chrono::steady_clock::time_point modeling_end = std::chrono::steady_clock::now();
        std::cout << "Modeling took " << std::chrono::duration_cast<std::chrono::milliseconds> (modeling_end - modeling_start).count() << "[ms]" << std::endl;
        printf("Total data collected %f Gb\n", total_data_captured/1024);
        printf("Total data dumped %f Gb\n", total_data_sent/1024);
        /* or (int i = 0; i < m_stations.size(); i++) {
            m_station& obs = m_stations[i];
            printf("Dumped data from %s : %f\n", obs.id.c_str(), obs.data_dumped);

        }*/
        printf("System time without overflow %f\n", sytem_time_no_overflow);
        printf("Total time in overflow %f\n", total_time_overflow);
        printf("Total time in monitoring  %f\n", total_time_monitoring);
        printf("Total time in dumping %f\n", total_time_dumping);
        printf("Total time dumping when not in shadow %f\n", total_time_dumping_instead_of_monitoring);
        perf_metric = (sytem_time_no_overflow / 60.0) + total_data_sent/1024;

        printf("Estimated points: %f\n", perf_metric);
    }

    /*std::map <std::string, std::vector<station_datapoint> > prepare_solution(int ds_step = 1) {
        std::map <std::string, std::vector<station_datapoint> > Res;

        for (int i = 0; i < m_stations.size(); i++) {
            Res[m_stations[i].id] = extract_solution(m_stations[i]);
        }
        return Res;
    }
    */
    /*
    void dump_solutions(int ds_step = 1) {
        std::string solution_dir = "./solution";
        std::filesystem::create_directories(solution_dir);

        for (int i = 0; i < m_stations.size(); i++) {

            std::string fn = solution_dir + "//" + m_stations[i].id + ".res";
            dump_solution_to_file(m_stations[i], fn);
        }
    }
    */
};


bool SDP_comparator(station_datapoint& a, station_datapoint& b) {
    return (a.time_start < b.time_start);
}

bool compare_status_pair(std::pair<double, std::string>& fst, std::pair<double, std::string>& snd) {
    return fst.first < snd.first;
}

bool validate_sputnik_log(sputnik& sp, std::vector<station_datapoint>& sp_log, int maxtime) {
    //consistency check, just in case
    for (int i = 0; i < sp_log.size(); i++) {
        station_datapoint& dp = sp_log[i];
        if (dp.sputnik != sp.id) {
            printf("Interval %s is not for the current sputnik %s\n", dp.print_sdp().c_str(), sp.id.c_str());
        }
    }
    if (sp_log.size() > 1) {
        for (int i = 0; i < sp_log.size() - 1; i++) {
            station_datapoint& dp_cur = sp_log[i];
            station_datapoint& dp_next = sp_log[i + 1];
            if (dp_cur.time_end > dp_next.time_start) {
                printf("Intervals %s and %s intersect\n", dp_cur.print_sdp().c_str(), dp_next.print_sdp().c_str());
                return false;
            }
        }
    }

    //next we need to construct a sequence of sputnik statuses from the log and its area access status

    std::vector<std::pair<double, std::string>> statuses;

    //    std::map<double, std::string> relevant_timepoints;

    for (int i = 0; i < sp.AreaAccess.size(); i++) {
        if (sp.AreaAccess[i][0] < maxtime) {
            std::pair<double, std::string> tmp;
            tmp.first = sp.AreaAccess[i][0];
            tmp.second = "Area in sight";
            statuses.push_back(tmp);
            //relevant_timepoints[sp.AreaAccess[i][0]] = "Area in sight";         
        }
        if (sp.AreaAccess[i][1] < maxtime) {
            std::pair<double, std::string> tmp;
            tmp.first = sp.AreaAccess[i][1];
            tmp.second = "Area out of sight";
            statuses.push_back(tmp);
            //relevant_timepoints[sp.AreaAccess[i][1]] = "Area out of sight";
        }
    }

    for (int i = 0; i < sp_log.size(); i++) {
        if (sp_log[i].time_start < maxtime) {
            std::pair<double, std::string> tmp;
            tmp.first = sp_log[i].time_start;
            tmp.second = "Dumping start";
            statuses.push_back(tmp);

            //relevant_timepoints[sp_log[i].time_start] = "Dumping start";
        }
        if (sp_log[i].time_end < maxtime) {
            std::pair<double, std::string> tmp;
            tmp.first = sp_log[i].time_end;
            tmp.second = "Dumping end";
            statuses.push_back(tmp);

            //relevant_timepoints[sp_log[i].time_end] = "Dumping end";
        }
    }
    std::sort(statuses.begin(), statuses.end(), compare_status_pair);
    //std::vector<std::pair<double, std::string>> statuses;
    //now model sputnik behavior at this time
    /*for (auto& a : relevant_timepoints) {
        statuses.push_back(a);
    }*/

    //pad the list to ensure correct processing
    if (statuses[statuses.size() - 1].second == "Dumping start") {
        std::pair<double, std::string> t;
        t.first = double(maxtime);
        t.second = "Dumping end";
        statuses.push_back(t);
    }

    if (statuses[statuses.size() - 1].second == "Area in sight") {
        std::pair<double, std::string> t;
        t.first = double(maxtime);
        t.second = "Area out of sight";
        statuses.push_back(t);
    }

    double current_storage = 0;

    bool dumping = false;
    bool monitoring = false;
    bool area_in_sight = false;
    double dumping_started = 0;
    double monitoring_started = 0;

    bool overflow = false;

    for (int i = 0; i < statuses.size(); i++) {
        if (statuses[i].second == "Area in sight") {
            area_in_sight = true;
            if (dumping == false) {
                monitoring = true;
                monitoring_started = statuses[i].first;
            }
        }
        if (statuses[i].second == "Area out of sight") {
            area_in_sight = false;
            if (dumping == false) {
                current_storage += (double)sp.capture_speed * (statuses[i].first - monitoring_started);
                if (current_storage > sp.storage_size) {
                    overflow = true;
                    current_storage = sp.storage_size;
                }
                monitoring = false;
            }
        }
        if (statuses[i].second == "Dumping start") {
            if (monitoring == true) {
                current_storage += (double)sp.capture_speed * (statuses[i].first - monitoring_started);
                if (current_storage > sp.storage_size) {
                    overflow = true;
                    current_storage = sp.storage_size;
                }
                monitoring = false;
            }
            dumping = true;
            dumping_started = statuses[i].first;
        }
        if (statuses[i].second == "Dumping end") {
            dumping = false;
            double dumped_data = (double)sp.transfer_speed * (statuses[i].first - dumping_started);
            current_storage -= dumped_data;
            overflow = false;
            if ((current_storage < 0) && (abs(current_storage) > 0.0001)) {


                printf("Sputnik %s transmitted more data than it had resulting in %f current storage\n", sp.id.c_str(), current_storage);

                return false;
            }

            if (area_in_sight) {
                monitoring = true;
            }
        }
    }

    //    printf("Sputnik %s seems to be ok\n",sp.id.c_str());
    return true;

}


bool validate_solution(std::vector<sputnik>& sputniks, std::vector<station>& stations, std::map <std::string, std::vector<station_datapoint> >& Solution, int maxtime) {

    // consistency check

    for (auto& m : stations) {
        //check whether station is in the solution
        if (Solution.count(m.id) == 0) {
            printf("Station %s is not found in the solution\n", m.id.c_str());
            return false;
        }

        //for each station ensure that intervals are ordered and do not intersect
        for (int i = 0; i < Solution[m.id].size() - 1; i++) {
            station_datapoint& dp_cur = Solution[m.id][i];
            station_datapoint& dp_next = Solution[m.id][i + 1];
            if (dp_cur.time_end > dp_next.time_start) {
                printf("Intervals %s and %s intersect\n", dp_cur.print_sdp().c_str(), dp_next.print_sdp().c_str());
                return false;
            }
        }

        //for each station ensure that intervals are in order

        for (int i = 0; i < Solution[m.id].size(); i++) {

            station_datapoint& dp = Solution[m.id][i];
            if (dp.station != m.id) {
                printf("Interval %s is not for the current station %s\n", dp.print_sdp().c_str(), m.id.c_str());
            }

            if (dp.time_start >= dp.time_end) {
                printf("Interval %s start & end points are incorrect\n", dp.print_sdp().c_str());
                return false;
            }
            if ((dp.time_end - dp.time_start) != dp.duration) {
                printf("Interval %s duration is incorrect\n", dp.print_sdp().c_str());
                return false;
            }
            //find sputnik in sputniks
            int sp_id = -1;
            for (int j = 0; j < sputniks.size(); j++) {
                if (sputniks[j].id == dp.sputnik) {
                    sp_id = j;
                    break;
                }
            }

            if (sp_id == -1) {
                printf("Sputnik from %s not found\n", dp.print_sdp().c_str());
                return false;
            }
            else {
                //compute how much data could sputnik send in this time
                double ds = sputniks[sp_id].transfer_speed * dp.duration ;
                if (abs(dp.data_sent - ds) > 0.001) {
                    printf("Sputnik could not have sent this amount of data %s \n", dp.print_sdp().c_str());
                    printf("Correct data sent should be %f \n", ds);
                    return false;
                }
            }

            //check that sputnik was visible to station during this whole interval 
            //std::map < std::string, std::vector<std::vector<double> > > 
            int SA_int_index = -1;
            for (int j = 0; j < m.SatelliteAccess[dp.sputnik].size(); j++) {
                std::vector<double>& SA_interval = m.SatelliteAccess[dp.sputnik][j];
                if ((SA_interval[0] <= dp.time_start) && (SA_interval[1] >= dp.time_end)) {
                    SA_int_index = j;
                    break;
                }
            }
            if (SA_int_index == -1) {
                printf("Sputnik from %s was not visible to station during this interval\n", dp.print_sdp().c_str());
                return false;
            }
        }
    }

    printf("Stations logs checked, proceeding to sputniks\n");


    for (int i = 0; i < sputniks.size(); i++) {
        sputnik& sp = sputniks[i];

        //reconstruct the log for this sputnik
        std::vector<station_datapoint> sputnik_log;
        for (auto& m : stations) {
            for (int j = 0; j < Solution[m.id].size(); j++) {
                station_datapoint& dp = Solution[m.id][j];
                if (dp.sputnik == sp.id) {
                    sputnik_log.push_back(dp);
                }
            }
        }
        //sort sputnik log
        std::sort(sputnik_log.begin(), sputnik_log.end(), SDP_comparator);
        bool r = validate_sputnik_log(sp, sputnik_log, maxtime);
        if (r == false) {
            return false;
        }
    }
    return true;
}







/*struct modeler_params {
    uint32_t Dontdumpuntil = 0;
    //in Gb
    double Allow_initial_accumulation = 30;


    bool Delay_in_shadow = true;
    bool Interrupt_dumping_to_delay_in_shadow = true;
    double Dis_reduce_coeff = 0.1;
    double Storage_scaling_coeff = 0.1;
    double In_shadow_coeff = 1.5;
};
*/
void print_help() {
    printf("The application expects paths to csv files produced via specific script\n");
    printf("The said csv files should contain the same data as original files, but \n");
    printf("with datetime converted to seconds starting from 1.06.2027 \n");
    printf("The parameters include discretisation step = 1 for 1 second, 10 for 10 seconds, etc.\n");
    printf("The application is a basic proof-of-concept and is (very) likely to contain bugs.\n");
    printf("TL;DR: To use: invoke ./app [path_to Data_csv] [discretisation_step from 1 to 100]\n");
    printf("Without path to csv specified app will look for it in the current folder\n");
    printf("Default discretisation value is 1\n");
    printf("Solution is printed to separate files in Solution folder\n");

}

int main(int argc, char* argv[]) {
    //11044.049

    dt_ffs base_time(2027, 6, 1, 0, 0, 0);
    dt_ffs t(11607.124, base_time);
    std::string sss = t.to_string();

    std::string sputnik_path = ".\\satellites\\";
    std::string station_path = ".\\stations\\";
    //in seconds;
    double discretization_interval = 1;
    int maxtime = 14 * 24 * 60 * 60;
    //int maxtime =  24 * 60 * 60 * discretization_step;

    if (argc > 1) {
        if ((std::string(argv[1]) == "-h") || (std::string(argv[1]) == "-help")) {
            print_help();
            exit(0);
        }
        else {
            if (argc == 1) {
                std::string prefix_path = ".";
                sputnik_path = prefix_path + sputnik_path;
                station_path = prefix_path + station_path;

            }
            if (argc >= 2) {
                std::string prefix_path(argv[1]);
                sputnik_path = prefix_path + sputnik_path;
                station_path = prefix_path + station_path;
            }
            if (argc >= 3) {
                discretization_interval = std::atof(argv[2]);
            }
        }
    }
    printf("Attempting to load data from default locations and work with default parameters\n");
    std::vector<sputnik> sputniks;
    std::vector<station> stations;

    //std::cout << "Time difference = " << std::chrono::duration_cast<std::chrono::nanoseconds> (end - begin).count() << "[ns]" << std::endl;
    std::chrono::steady_clock::time_point preparation_start = std::chrono::steady_clock::now();

    sputniks = load_sputnik_info(sputnik_path);
    stations = load_station_info(station_path);
    assert(discretization_interval >= 0.001);

    modeler m(sputniks, stations, discretization_interval, maxtime);
    std::chrono::steady_clock::time_point preparation_end = std::chrono::steady_clock::now();
    //std::cout << "Preparation took " << std::chrono::duration_cast<std::chrono::milliseconds> (preparation_end - preparation_start).count() << "[ms]" << std::endl;
    
    m.Enable_logging = true;
    m.run(true);

    if (validate_solution(sputniks, stations, m.SOL, maxtime)) {
        printf("Validation successful\n");
        print_solution(m.SOL);
    }
    //        m.run_simulation_plain(1000);

    /*for (int i = 0; i < 100; i++) {
        m.run(false);
        if (validate_solution(sputniks, stations, m.SOL, maxtime) == true) {
            printf("Validation successful\n");
        };
        m.reset();
    }*/


    //m.run_simulation(100);

    //m.dump_solutions();



}