#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <map>
#include <unordered_map>
#include <filesystem>
#include <cmath>
#include <set>
#include <chrono>
#include <assert.h>
#include <sstream>


enum sputnik_status { SputnikIdle, Monitoring, SputnikDumping, Overflow };
enum session_break{Start_monitoring, Start_dumping, Out_of_range, Dumped_all_data, Delay_in_shadow, Switched_to_other, OOM };
enum station_status { StationIdle, StationDumping };

struct modeler_params {
    uint32_t Dontdumpuntil = 0;
    //in Gb
    double Allow_initial_accumulation = 30;


    bool Delay_in_shadow = true;
    bool Interrupt_dumping_to_delay_in_shadow = true;
    double Dis_reduce_coeff = 0.1;
    double Storage_scaling_coeff = 0.1;
    double In_shadow_coeff = 1.5;
};


std::vector<std::string> split(std::string s, std::string delimiter) {
    size_t pos_start = 0, pos_end, delim_len = delimiter.length();
    std::string token;
    std::vector<std::string> res;

    while ((pos_end = s.find(delimiter, pos_start)) != std::string::npos) {
        token = s.substr(pos_start, pos_end - pos_start);
        pos_start = pos_end + delim_len;
        res.push_back(token);
    }

    res.push_back(s.substr(pos_start));
    return res;
}


struct sputnik {
    std::string id = "";
    std::string type = "";
    double transfer_speed = 0;
    double initial_storage = 0;
    double storage_size = 0;
    double capture_speed = 0; 
    std::vector<std::vector<double> > AreaAccess;
    void from_file(std::string filename) {
        std::ifstream file(filename);
        std::vector<std::string> s_tmp = split(filename, "\\");
                
        id = s_tmp[s_tmp.size() - 1];
        id = id.substr(0, id.size() - 3);
        std::string kino = "Kinosputnik";
        std::string zorky = "Zorky";

        if (id.substr(0, kino.size()) == kino) {
            type = "Kinosputnik";
            id = id.substr(kino.size() + 1, id.size() - kino.size() - 2);
            
            storage_size = 1000;
            transfer_speed = 0.125;
            capture_speed = 0.5;
        }
        else {
            //Zorky
            type = "Zorky";
            id = id.substr(zorky.size() + 1, id.size() - zorky.size() - 2);            
            storage_size = 500;
            transfer_speed = 0.03125;
            capture_speed = 0.5;
        }

        if (file.is_open()) {
            std::string line;
            while (std::getline(file, line)) {

                std::vector<std::string> tmp = split(line, ",");
                std::vector<double> tmp_int;
                for (unsigned int j = 0; j < tmp.size(); j++) {
                    tmp_int.push_back(std::stod(tmp[j]));
                }
                AreaAccess.push_back(tmp_int);

            }
        }        
    }

    
};

struct station {
    std::string id = "";
    std::map < std::string, std::vector<std::vector<double> > > SatelliteAccess;
    void from_file(std::string filename) {
        std::ifstream file(filename);
        std::vector<std::string> s_tmp = split(filename, "\\");

        id = s_tmp[s_tmp.size() - 1];
        id = id.substr(0, id.size() - 4);

        //a.id = ?
        std::vector<std::vector<double> > intervals;
        unsigned int counter = 0;
        if (file.is_open()) {

            std::string line;
            std::string current_sputnik = "";

            while (std::getline(file, line)) {
                if (line[0] == '*') {
                    if (intervals.size() != 0) {
                        SatelliteAccess[current_sputnik] = intervals;
                        intervals.clear();
                    }
                    current_sputnik = line.substr(1, line.size() - 1);
                    counter++;
                }
                else {
                    std::vector<std::string> tmp = split(line, ",");
                    std::vector<double> tmp_int;
                    for (unsigned int j = 0; j < tmp.size(); j++) {
                        tmp_int.push_back(std::stod(tmp[j]));
                    }
                    intervals.push_back(tmp_int);
                }
            }
        }
    }
};  



std::vector<sputnik> load_sputnik_info(std::string pathname) {
    std::vector<std::string> list_of_files;
    for (const auto& entry : std::filesystem::directory_iterator(pathname))
        list_of_files.push_back(entry.path().string());

    std::vector<sputnik> sputniks;
    for (int i = 0; i < list_of_files.size(); i++) {        
        sputnik t;
        t.from_file(list_of_files[i]);
        sputniks.push_back(t);
    }
    return sputniks;
}

std::vector<station> load_station_info(std::string pathname) {
    
    std::vector<station> stations;
    std::vector<std::string> list_of_files;
    for (const auto& entry : std::filesystem::directory_iterator(pathname))
        list_of_files.push_back(entry.path().string());

    for (int i = 0; i < list_of_files.size(); i++) {
        station t;
        t.from_file(list_of_files[i]);
        stations.push_back(t);
    }
    return stations;

}

struct m_sputnik_log_entry {
    uint32_t time_moment = 0;
    sputnik_status old_status;
    sputnik_status new_status;
    
    double dumped_data = 0;
    std::string connected_station = "";
    
    

    m_sputnik_log_entry(uint32_t TM, sputnik_status OS, sputnik_status NS, double DD, std::string CS) {
        time_moment = TM;
        old_status = OS;
        new_status = NS;
        dumped_data = DD;
        connected_station = CS;
    }
    
};

struct m_station_log_entry {
    uint32_t time_moment = 0;
    station_status old_status;
    session_break reason;

    double dumped_data = 0;
    std::string connected_sputnik = "";

    m_station_log_entry(uint32_t TM, station_status OS, session_break DS, double DD, std::string CS) {
        time_moment = TM;
        old_status = OS;
        reason = DS;
        dumped_data = DD;
        connected_sputnik = CS;
    }
   
};

struct m_sputnik {
    std::string id = "";
    sputnik_status current_status = sputnik_status::SputnikIdle;
    double current_storage = 0;
    double captured_total = 0;
    double storage_size = 0;
    double capture_speed = 0;
    double transfer_speed = 0;
    bool only_one_for_station = false;
    
    std::unordered_map<int, int> Earth_in;
    std::unordered_map<int, int> Earth_out;
    bool in_shadow = true;
    uint32_t next_shadow = 0;
    std::vector<m_sputnik_log_entry> log;
    std::string sending_to = "";

    m_sputnik(sputnik t, int discretization_step) {
        only_one_for_station = false;
        in_shadow = true;
        id = t.id;        
        current_status = SputnikIdle;
        current_storage = 0;
        storage_size = t.storage_size;
        capture_speed = t.capture_speed / discretization_step;
        transfer_speed = t.transfer_speed / discretization_step;
        sending_to = "";
        next_shadow = 0;
        for (int i = 0; i < t.AreaAccess.size(); i++) {
            std::vector<double> interval = t.AreaAccess[i];
            int ind0 = std::ceil(interval[0] * discretization_step);
            int ind1 = std::floor(interval[1] * discretization_step)-1;
            if (ind1 >= ind0 + 2) {
                Earth_in[ind0] = ind1 - ind0;
                Earth_out[ind1] = 1;
            }
        }
    }
};

struct m_station {
    std::string id = "";
    station_status current_status;
    double data_dumped = 0;   
    double current_dumped = 0;
    std::set <std::string> currently_visible;
    
    std::unordered_map<int, std::vector<std::string>> sputnik_in;
    std::unordered_map<int, std::vector<std::string>> sputnik_out;
    
    std::vector<m_station_log_entry> log;
    std::string dumping_from = "";

    m_station(station t, int discretization_step) {
        id = t.id;        
        current_status = StationIdle;
        dumping_from = "";
        for (auto &Sp : t.SatelliteAccess){
            
            for (int i = 0; i < Sp.second.size();i++){            
                std::vector<double> interval = Sp.second[i] ;
                int ind0 = std::ceil(interval[0] * discretization_step);
                int ind1 = std::floor(interval[1] * discretization_step) - 1;            
                if (ind1 >= ind0 + 2) {
                    sputnik_in[ind0].push_back(Sp.first);
                    sputnik_out[ind1].push_back(Sp.first);
                }
            }
        }
    }
};

struct dt_ffs {
    uint32_t year;
    uint32_t month;
    uint32_t day;
    uint32_t hour;
    uint32_t minute;
    double seconds;
    
    std::vector<int> months_size = { 31,28,31,30,31,30, 31,30,31,31,30,31 };
    std::vector<std::string> months = { "Jan", "Feb", "Mar", "Apr",
        "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };

    dt_ffs() {
        year = 0;
        month = 0;
        day = 0;
        hour = 0;
        minute = 0;
        seconds = 0;
    }
    dt_ffs(uint32_t y, uint32_t mo, uint32_t d, uint32_t h, uint32_t mi, double s) {
        year = y;
        month = mo;
        day = d;
        hour = h;
        minute = mi;
        seconds = s;
    }

    dt_ffs(double time_sec, dt_ffs base) {
        assert(time_sec <= UINT32_MAX);
        double residual = 0;
        uint32_t ts_rounded = std::floor(time_sec);
        residual = time_sec - ts_rounded;
        // screw leap years
        
        year =  ts_rounded / (365 * 24 * 60 * 60);
        uint32_t rem_1 = ts_rounded % (365 * 24 * 60 * 60);        
        uint32_t remaining_days = rem_1 / (24 * 60 * 60);

        uint32_t cm = 0;
        while (remaining_days > months_size[cm]){
            remaining_days -= months_size[cm];
            cm++;
        }
        month = cm;        
        day = remaining_days;

        uint32_t rem_2 = ts_rounded % (24 * 60 * 60);

        hour =  rem_2 / (60 * 60);

        uint32_t rem_3 = rem_2 % (60*60);
        minute = rem_3 / 60;

        seconds = rem_3 % 60 + residual;

        assert(base.hour == 0);
        assert(base.minute == 0);
        assert(base.seconds == 0);

        year = year + base.year;
        month = month + base.month;
        day = day + base.day;       

    }
    std::string to_string() {
        std::string res;
        res = std::to_string(day) + " " + months[month-1] + " " + std::to_string(year)+ " ";
        if (hour < 10) {
            res += "0";
        }
        res += std::to_string(hour);
        res += ":";
        if (minute < 10) {
            res += "0";
        }
        res += std::to_string(minute);
        res += ":";
        
        if (seconds < 10) {
            res += "0";
        }
        uint32_t sv = std::floor(seconds);
        uint32_t residual = std::floor((seconds - sv) * 1000);
        res += std::to_string(sv);
        res += ".";
        if (residual == 0) {
            res += "0";
        }
        else {
            res += std::to_string(residual);
        }

        return res;
    }


};


static void dump_solution_to_file(m_station &obs, std::string filename, int ds_step = 1) {
    std::ofstream outfile;
    outfile.open(filename.c_str());
    outfile << obs.id << std::endl;
    outfile << "-------------------------" << std::endl;
    uint32_t access_counter = 1;
    uint32_t interval_start = 0;
    uint32_t interval_end = 0;
    double data_sent = 0;
    std::string sputnik_from = "";
    double total_dumped = 0;
    
    
    outfile << "Access * Start Time (UTCG) * Stop Time (UTCG) * Duration (sec) * Sat * Data (Mbytes)" << std::endl;
    dt_ffs base_time(2027, 6, 1, 0, 0, 0);
    for (int i = 0; i < obs.log.size(); i++) {
        m_station_log_entry& m = obs.log[i];
        if (m.reason == Start_dumping) {
            assert(interval_start == 0);
            assert(interval_end == 0);
            assert(data_sent == 0);
            assert(sputnik_from == "");
            interval_start = m.time_moment/ds_step;
            sputnik_from = m.connected_sputnik;
        }
        if ((m.reason == Out_of_range)||(m.reason == Switched_to_other)||(m.reason == Dumped_all_data)||(m.reason == Delay_in_shadow) || (m.reason == OOM)) {
            assert(sputnik_from == m.connected_sputnik);
            interval_end = m.time_moment/ds_step;
            data_sent = m.dumped_data;
            uint32_t duration = interval_end - interval_start;
            
            std::string r = std::to_string(access_counter) + "\t" + dt_ffs(interval_start, base_time).to_string();
            r += "\t" + dt_ffs(interval_end, base_time).to_string() + "\t" + std::to_string(duration) + "\t";
            r += sputnik_from + "\t" + std::to_string(data_sent*1000);
            total_dumped += data_sent;

            outfile << r << std::endl;
            access_counter++;
            interval_start = 0;
            interval_end = 0;
            sputnik_from = "";
            data_sent = 0;
        }
        //m_station_log_entry so(tm, co.current_status, Start_dumping, 0 , cs.id);

        // m_station_log_entry so(tm, co.current_status, DES, data_dumped, cs.id);
    }
    outfile.close();
    // printf("%s dumped %f data in total\n", obs.id, total_dumped);


}

struct modeler {
    std::vector<m_sputnik> m_sputniks;
    std::vector<m_station> m_stations;
    std::map<std::string, int> sputnik_id_map;
    std::map<std::string, int> station_id_map;
    const double bad_fitness = -1000000;
    uint32_t ds_step = 1;
    uint32_t max_time = 0;
    uint64_t total_time_monitoring = 0;
    uint64_t total_time_overflow = 0;
    uint64_t total_time_dumping = 0;
    uint64_t total_time_dumping_instead_of_monitoring = 0;
    double total_data_captured = 0;
    double total_data_sent = 0;
    double perf_metric = 0;

    //performance metrics
    uint64_t sytem_time_no_overflow = 0;

    //parameters
    uint32_t dontdumpuntil = 0;
    //in Gb
    double allow_initial_accumulation = 30;    

        
    bool delay_in_shadow = true;
    bool interrupt_dumping_to_delay_in_shadow = true;
    bool allow_station_idle_to_delay_in_shadow = true;
    bool update_OOR = true;

    double in_shadow_coeff = 1.5;
    

    void reset() {
        total_time_monitoring = 0;
        total_time_overflow = 0;
        total_time_dumping = 0;
        total_time_dumping_instead_of_monitoring = 0;
        total_data_captured = 0;
        total_data_sent = 0;

        for (uint32_t m_ind = 0; m_ind < m_stations.size(); m_ind++) {
            m_station& obs = m_stations[m_ind];
            obs.current_status = StationIdle;
            obs.current_dumped = 0;
            obs.currently_visible.clear();
            obs.data_dumped = 0;
            obs.dumping_from = "";
            obs.log.clear();            
        }

        for (uint32_t s_ind = 0; s_ind < m_sputniks.size(); s_ind++) {
            m_sputnik& st = m_sputniks[s_ind];
            st.captured_total = 0;
            st.current_status = SputnikIdle;
            st.current_storage = 0;
            st.in_shadow = true;
            st.log.clear();
            st.next_shadow = 0;
            st.sending_to = "";            
        }
    }


    void stop_dumping(m_sputnik& cs, m_station& co, uint32_t & tm, session_break DES) {
     
        //stop dumping and update sputnik log    
        double data_dumped = co.current_dumped;    
        if ((cs.id == "KinoSat_110308") && (data_dumped == 224.5)) {
            printf("s");
        }
        //m_sputnik_log_entry(uint32_t &TM, sputnik_status &OS, sputnik_status &NS, double &DD, std::string &CS) {        
        
        assert(cs.sending_to == co.id);
        assert(co.dumping_from == cs.id);
        
        m_sputnik_log_entry sl(tm, cs.current_status, SputnikIdle, data_dumped, co.id);
        if (cs.in_shadow == false) {
            sl.new_status = Monitoring;
        }
        cs.log.push_back(sl);
        cs.sending_to = "";
        cs.current_status = sl.new_status;
        

        m_station_log_entry so(tm, co.current_status, DES, data_dumped, cs.id);
        co.log.push_back(so);
        co.dumping_from = "";
        co.current_dumped = 0;
        co.current_status = StationIdle;

    }

    void start_dumping(m_sputnik& cs, m_station& co, uint32_t& tm) {
        //stop dumping and update sputnik log    
        
        //m_sputnik_log_entry(uint32_t &TM, sputnik_status &OS, sputnik_status &NS, double &DD, std::string &CS) {        

        assert(cs.sending_to == "");
        assert(co.dumping_from == "");

        m_sputnik_log_entry sl(tm, cs.current_status, SputnikDumping, 0, co.id);        
        cs.log.push_back(sl);
        cs.sending_to = co.id;
        cs.current_status = sl.new_status;


        m_station_log_entry so(tm, co.current_status, Start_dumping, 0 , cs.id);
        co.log.push_back(so);
        co.dumping_from = cs.id;
        co.current_dumped = 0;
        co.current_status = StationDumping;
    }

    double compute_fitness(std::string sputnik_id, uint32_t time_moment) {
        if (sputnik_id == "") {
            return bad_fitness;
        }
        uint32_t sputnik_index = sputnik_id_map[sputnik_id];
        m_sputnik& m = m_sputniks[sputnik_index];
        bool bad_point = false;
        bool sputnik_will_not_overflow_until_shadow = (m.in_shadow == false) && (delay_in_shadow == true) &&
            (((m.storage_size - m.current_storage) / m.capture_speed) >= (m.next_shadow - time_moment));

        bad_point |= (m.current_status == SputnikDumping);        
        bad_point |= (m.current_storage == 0);
        bad_point |= (m.current_storage == m.captured_total) and (m.current_storage <= allow_initial_accumulation);        
        bad_point |= (m.current_storage / m.transfer_speed) < 5;
        bad_point |= allow_station_idle_to_delay_in_shadow && sputnik_will_not_overflow_until_shadow;        

        
        if (bad_point == true) {
            return bad_fitness;
        }
        assert(m.id == sputnik_id);

        double res = 0;
        if (m.current_status != SputnikDumping) {
            double r0 = -m.current_storage / m.storage_size;
            double r1 = -m.current_storage / m.transfer_speed;
            double r2 = 100.0 * ((m.storage_size - m.current_storage) / m.capture_speed) / (m.next_shadow - time_moment);
            // numerator == how many seconds can satellite capture data until overflow
            // denumerator == how many seconds until it goes into shadow
            double r3 = -100 * (m.current_storage / m.transfer_speed) / (m.next_shadow - time_moment);
            double r4 = (m.storage_size - m.current_storage) / m.storage_size;
            
            // numerator == how many seconds satellite needs to transfer data until empty
            // denumerator == how many seconds until it goes into shadow

            res = r3;

            //res = -(m.storage_size - m.current_storage) / m.storage_size;
        }
                

        return res;
    }

    modeler(std::vector<sputnik> sputniks, std::vector<station> stations, int Discretization_step, int Maximum_time) {
        ds_step = Discretization_step;
        max_time = Maximum_time;
        
        for (int i = 0; i < sputniks.size(); i++) {
            m_sputnik t(sputniks[i], ds_step);
            m_sputniks.push_back(t);
            sputnik_id_map[t.id] = m_sputniks.size() - 1;
        }

        for (int i = 0; i < stations.size(); i++) {
            m_station t(stations[i], ds_step);
            m_stations.push_back(t);
            station_id_map[t.id] = m_stations.size() - 1;
        }
    }

    void run() {
        std::chrono::steady_clock::time_point modeling_start = std::chrono::steady_clock::now();
                
        std::vector<bool> can_update(m_stations.size(), false);
        for (uint32_t i = 0; i < max_time; i++) {
            bool in_overflow = false;
            if ((i > 0) and (i % 100000 == 0)) {
                printf("Current status %u out of %u\n", i, max_time);
            }

            for (uint32_t s_ind = 0; s_ind < m_sputniks.size(); s_ind++) {
                m_sputnik& sp = m_sputniks[s_ind];
                auto it_in = sp.Earth_in.find(i);
                if (it_in != sp.Earth_in.end()) {
                    sp.in_shadow = false;
                    sp.next_shadow = i + it_in->second;
                    if (sp.current_status == SputnikIdle) {
                        sp.current_status = Monitoring;
                        assert(sp.sending_to == "");
                        m_sputnik_log_entry sl(i, SputnikIdle, Monitoring, 0, "");
                        sp.log.push_back(sl);
                    }
                }
                auto it_out = sp.Earth_out.find(i);
                if (it_out != sp.Earth_out.end()) {
                    sp.in_shadow = true;
                    sp.next_shadow = 0;
                    if (sp.current_status == Monitoring) {
                        sp.current_status = SputnikIdle;
                        assert(sp.sending_to == "");
                        m_sputnik_log_entry sl(i, Monitoring, SputnikIdle, 0, "");
                        sp.log.push_back(sl);
                    }
                }

                if (sp.current_status == SputnikDumping) {

                    assert(sp.sending_to != "");

                    m_station& co = m_stations[station_id_map[sp.sending_to]];

                    if (sp.current_storage <= 0) {
                        //small error can accumulate
                        total_data_sent -= sp.current_storage;
                        co.current_dumped -= sp.current_storage;
                        co.data_dumped -= sp.current_storage;
                        sp.current_storage = 0;
                        stop_dumping(sp, co, i, Dumped_all_data);

                    }
                    if ((delay_in_shadow == true) && (interrupt_dumping_to_delay_in_shadow == true) && (sp.in_shadow == false) && (sp.only_one_for_station == false)) {
                        //estimate whether it will be possible to work 
                        //uninterrupted until the shadow.
                        double data_till_shadow = (sp.next_shadow - i) * sp.capture_speed;
                        if (sp.current_storage + data_till_shadow <= sp.storage_size) {
                            stop_dumping(sp, co, i, Delay_in_shadow);
                        }
                    }
                }
            }
            


         
            std::set<std::string> OOR_sputniks;
            //remove satellites that move out of range            
            for (uint32_t m_ind = 0; m_ind < m_stations.size(); m_ind++) {
                can_update[m_ind] = false;

                m_station& obs = m_stations[m_ind];
                
                auto it = obs.sputnik_out.find(i);
                if (it != obs.sputnik_out.end()) {
                    for (int j = 0; j < it->second.size(); j++) {
                        //if info is being dumped from this satellite then stop dumping and update logs
                        if (obs.dumping_from == it->second[j]) {
                            m_sputnik& cs = m_sputniks[sputnik_id_map[it->second[j]]];
                            //stop dumping and update sputnik log                            
                            stop_dumping(cs, obs, i, Out_of_range);
                            OOR_sputniks.insert(it->second[j]);
                        }                       
                        //remove from visibility list
                        obs.currently_visible.erase(it->second[j]);
                    }
                }
            }


            //add satellites that move into range
            for (uint32_t m_ind = 0; m_ind < m_stations.size(); m_ind++) {
                m_station& obs = m_stations[m_ind];
                auto it = obs.sputnik_in.find(i);
                if (it != obs.sputnik_in.end()){
                    can_update[m_ind] = true;
                    for (int j = 0; j < it->second.size(); j++) {                       
                        obs.currently_visible.insert(it->second[j]);
                    }                
                }
            }
            if ((update_OOR) && (OOR_sputniks.size() > 0)){
                for (uint32_t m_ind = 0; m_ind < m_stations.size(); m_ind++) {
                    if (can_update[m_ind] == false) {
                        m_station& obs = m_stations[m_ind];
                        for (std::string sp_id : OOR_sputniks) {                                                            
                            if (obs.currently_visible.find(sp_id) != obs.currently_visible.end()) {
                                can_update[m_ind] = true;
                                break;
                            }
                        }
                    }
                }
            }


            //update connections between stations and satellites

            for (uint32_t m_ind = 0; m_ind < m_stations.size(); m_ind++) {
                if (can_update[m_ind] == true){
                    m_station& obs = m_stations[m_ind];
                    if (i >= dontdumpuntil){
                        if (obs.current_status == StationIdle) {
                            std::map<std::string, float> Fitness_values;
                            for (auto& it : obs.currently_visible) {
                                double tmp = compute_fitness(it, i);
                                if (tmp != bad_fitness) {
                                    Fitness_values[it] = tmp;
                                    //printf("Fitness %s %s @ %u = %f\n", obs.id, it, i, tmp);
                                }
                            }
                            //choose the sputnik with the best fitness
                        
                            std::string best_alt = obs.dumping_from;
                            double max_value = compute_fitness(best_alt,i);
                            for (auto& it : Fitness_values) {
                                if (it.second > max_value) {
                                    best_alt = it.first;
                                    max_value = it.second;
                                }
                            }
                            if (best_alt != obs.dumping_from) {
                                if (obs.dumping_from != "") {
                                    m_sputnik& cs = m_sputniks[sputnik_id_map[obs.dumping_from]];
                                    stop_dumping(cs, obs, i, Switched_to_other);
                                }
                                m_sputnik& cs = m_sputniks[sputnik_id_map[best_alt]];
                                if (Fitness_values.size() == 1) {
                                    cs.only_one_for_station = true;
                                }
                                else {
                                    cs.only_one_for_station = false;
                                }
                                start_dumping(cs, obs, i);
                            }
                        }                    
                    }
                }
            }

            for (uint32_t s_ind = 0; s_ind < m_sputniks.size(); s_ind++) {
                m_sputnik& sp = m_sputniks[s_ind];
                if (sp.current_status == Monitoring) {
                    if (sp.current_storage >= sp.storage_size){
                        sp.current_storage = sp.storage_size;
                        sp.current_status = Overflow;
                        m_sputnik_log_entry sl(i, Monitoring, Overflow, 0, "");
                        sp.log.push_back(sl);
                    }
                    else {
                        sp.current_storage += sp.capture_speed;
                        if (sp.current_storage >= sp.storage_size) {
                            sp.current_storage = sp.storage_size;
                        }
                        total_data_captured += sp.capture_speed;
                        sp.captured_total += sp.capture_speed;
                        total_time_monitoring++;
                    }
                }

                if ((sp.current_status == Overflow)&&(sp.in_shadow == false)){
                    total_time_overflow++;
                    in_overflow = true;
                }

                if (sp.current_status == SputnikDumping) {


                    assert(sp.current_storage > 0);
                    assert(sp.sending_to != "");

                    m_station& co = m_stations[station_id_map[sp.sending_to]];
                    co.current_dumped += sp.transfer_speed;
                    co.data_dumped += sp.transfer_speed;

                  
                    
                    sp.current_storage -= sp.transfer_speed;
                    total_data_sent += sp.transfer_speed;
                    
                    total_time_dumping++;
                    if (sp.in_shadow == false) {
                        total_time_dumping_instead_of_monitoring++;
                    }

                    
                }
            }

          
            if (in_overflow == false) {
                sytem_time_no_overflow++;
            }
        }
        //terminate all current sessions        
        for (uint32_t m_ind = 0; m_ind < m_stations.size(); m_ind++) {
            m_station& obs = m_stations[m_ind];

            if (obs.current_status == StationDumping) {
                m_sputnik& cs = m_sputniks[sputnik_id_map[obs.dumping_from]];
                //stop dumping and update sputnik log                            
                stop_dumping(cs, obs, max_time, OOM);
            }
        }



        printf("Modeling ended\n");
        std::chrono::steady_clock::time_point modeling_end = std::chrono::steady_clock::now();
        std::cout << "Modeling took " << std::chrono::duration_cast<std::chrono::milliseconds> (modeling_end - modeling_start).count() << "[ms]" << std::endl;
        printf("Total data collected %f\n", total_data_captured);
        printf("Total data dumped %f\n", total_data_sent);
        /* or (int i = 0; i < m_stations.size(); i++) {
            m_station& obs = m_stations[i];
            printf("Dumped data from %s : %f\n", obs.id.c_str(), obs.data_dumped);
            
        }*/
        printf("System time without overflow %u\n", sytem_time_no_overflow);
        printf("Total time in overflow %u\n", total_time_overflow);
        printf("Total time in monitoring %u\n", total_time_monitoring);
        printf("Total time in dumping %u\n", total_time_dumping);
        printf("Total time dumping when not in shadow %u\n", total_time_dumping_instead_of_monitoring);  
        perf_metric = (sytem_time_no_overflow / (60* ds_step)) + total_data_sent;

        printf("Estimated points: %f\n", perf_metric);
    }

    void dump_solutions(int ds_step = 1) {
        std::string solution_dir = "./solution";
        std::filesystem::create_directories(solution_dir);

        for (int i = 0; i < m_stations.size(); i++) {
            std::string fn = solution_dir + "//" + m_stations[i].id + ".res";
            dump_solution_to_file(m_stations[i], fn, ds_step);
        }

    }
};








/*struct modeler_params {
    uint32_t Dontdumpuntil = 0;
    //in Gb
    double Allow_initial_accumulation = 30;


    bool Delay_in_shadow = true;
    bool Interrupt_dumping_to_delay_in_shadow = true;
    double Dis_reduce_coeff = 0.1;
    double Storage_scaling_coeff = 0.1;
    double In_shadow_coeff = 1.5;
};
*/
void print_help() {
    printf("The application expects paths to csv files produced via specific script\n");
    printf("The said csv files should contain the same data as original files, but \n");
    printf("with datetime converted to seconds starting from 1.06.2027 \n");
    printf("The parameters include discretisation step = 1 for 1 second, 10 for 10 seconds, etc.\n");
    printf("The application is a basic proof-of-concept and is (very) likely to contain bugs.\n");
    printf("TL;DR: To use: invoke ./app [path_to Data_csv] [discretisation_step from 1 to 100]\n");
    printf("Without path to csv specified app will look for it in the current folder\n");
    printf("Default discretisation value is 1\n");
    printf("Solution is printed to separate files in Solution folder\n");
    
}

int main(int argc, char* argv[]) {
    

    std::string sputnik_path = "\\satellites\\";
    std::string station_path = "\\stations\\";
    int discretization_step = 1;
    int maxtime = 14 * 24 * 60 * 60 * discretization_step;


    if ((std::string(argv[1]) == "-h") || (std::string(argv[1]) == "-help")) {
        print_help();
        exit(0);
    }
    else {
        if (argc == 1) {
            std::string prefix_path = ".";
            sputnik_path = prefix_path + sputnik_path;
            station_path = prefix_path + station_path;

        }
        if (argc >= 2) {
            std::string prefix_path(argv[1]);
            sputnik_path = prefix_path + sputnik_path;
            station_path = prefix_path + station_path;
        }
        if (argc >= 3) {
            discretization_step = std::atoi(argv[2]);
        }
    }
    std::vector<sputnik> sputniks;
    std::vector<station> stations;
    
    //std::cout << "Time difference = " << std::chrono::duration_cast<std::chrono::nanoseconds> (end - begin).count() << "[ns]" << std::endl;
    std::chrono::steady_clock::time_point preparation_start = std::chrono::steady_clock::now();
    
    sputniks = load_sputnik_info(sputnik_path);
    stations = load_station_info(station_path);
    
    modeler m(sputniks, stations, discretization_step, maxtime);
    std::chrono::steady_clock::time_point preparation_end = std::chrono::steady_clock::now();
    //std::cout << "Preparation took " << std::chrono::duration_cast<std::chrono::milliseconds> (preparation_end - preparation_start).count() << "[ms]" << std::endl;
    
        
    m.run();
    m.dump_solutions(discretization_step);
    

  }